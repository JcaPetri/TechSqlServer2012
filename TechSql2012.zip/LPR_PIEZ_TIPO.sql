-- REPUESTOS TIPOS DE PIEZAS
SELECT TOP 100 EMP.[empr_nombre]
	  ,[emp_codigo]
      ,[tpi_codigo]
      ,[tpi_nombre]
      ,[tpi_descripcion]
      ,[tpi_estado]
      ,[tpi_coeficiente]
      ,[tpi_descconce]
  FROM [TechCoreDB].[dbo].[REP_TIPO_PIEZA] AS TIPIEZ
			INNER JOIN (SELECT * 
						FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
						) AS EMP ON
							TIPIEZ.[emp_codigo] = EMP.[empr_codigo]
WHERE [emp_codigo] = 2

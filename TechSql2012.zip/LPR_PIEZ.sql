-- Informaci�n de las piezas (esta es la lista de precios)
SELECT EMP.[empr_nombre]
	  ,PIEZ.[emp_codigo]
      ,PIEZ.[pie_codigo]
      ,PIEZ.[pie_numero_alternativo]
      ,PIEZ.[pie_numero]
      ,PIEZ.[pie_nombre]
--      ,PIEZ.[rub_codigo]
      ,PIEZ.[pie_alicuota]
      ,PIEZ.[tpi_codigo]
	  ,TPI.[tpi_nombre]
	  ,TPI.[tpi_coeficiente]
      ,PIEZ.[pie_precio_pagina] AS PCL
--      ,PIEZ.[pie_precio_vta_pub]
      ,PIEZ.[pie_unidad_empaque]
      ,PIEZ.[pie_stock_minimo]
      ,PIEZ.[pie_stock_maximo]
--      ,PIEZ.[pie_origen]
      ,PIEZ.[pie_fecha_alta]
      ,PIEZ.[pie_estado]
      ,PIEZ.[pie_vdm]
      ,PIEZ.[pie_fechacontrol]
      ,PIEZ.[pie_stock_maximo_mostrador]
      ,PIEZ.[pie_stock_maximo_taller]
      ,PIEZ.[pie_stock_minimo_mostrador]
      ,PIEZ.[pie_stock_minimo_taller]
 FROM [TechCoreDB].[dbo].[REP_PIEZAS] AS PIEZ 
	LEFT OUTER JOIN (SELECT [emp_codigo]
						  ,[tpi_codigo]
						  ,[tpi_nombre]
						  ,[tpi_descripcion]
						  ,[tpi_estado]
						  ,[tpi_coeficiente]
						  ,[tpi_descconce]
					  FROM [TechCoreDB].[dbo].[REP_TIPO_PIEZA]
					 ) AS TPI ON
						PIEZ.[emp_codigo] = TPI.[emp_codigo]
							AND
						PIEZ.[tpi_codigo] = TPI.[tpi_codigo]
	LEFT OUTER JOIN (SELECT * 
						FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
						) AS EMP ON
							PIEZ.[emp_codigo] = EMP.[empr_codigo]




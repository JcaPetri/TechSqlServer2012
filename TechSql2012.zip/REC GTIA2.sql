

SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_RECURSOS] RG
WHERE [odr_codigo] = '1107117'



-- Informaci�n de los recursos en garant�a
SELECT TOP 10 *, VH.*
FROM [TechCoreDB].[dbo].[TAL_RECURSOS] RG
	INNER JOIN (SELECT EC.[empr_nombre]
--					  ,GV.[emp_codigo]
					  ,GV.[veh_codigo]	
--					  ,GV.[mar_codigo]
					  ,MC.[mar_nombre]
--					  ,GV.[mod_codigo]
					  ,MD.[mod_nombre]
--					  ,GV.[smo_codigo]
					  ,SM.[smo_modfFabrica]
					  ,SM.[smo_nombre]
--					  ,GV.[veh_dominio]
--					  ,GV.[veh_nro_vin]
--					  ,GV.[veh_serie]
					  ,LEFT(GV.[veh_nro_motor],3) AS TipMotor
--					  ,GV.[veh_chasis]
--					  ,GV.[veh_marcachasis]
--					  ,GV.[veh_marcamotor]
--					  ,GV.[col_codigo]
--					  ,GV.[veh_concesionaria]
--					  ,GV.[veh_a�o_fab]
--					  ,GV.[veh_kilometraje]
--					  ,GV.[ubi_codigo]
--					  ,GV.[veh_placa_oval]
--					  ,GV.[veh_sucursal]
--					  ,GV.[veh_certificado]
--					  ,GV.[veh_fecha_certificado]
--					  ,GV.[veh_tipo_motor]
--					  ,GV.[veh_usado_nuevo]
--					  ,GV.[veh_nacional_importado]
--					  ,GV.[veh_observaciones]
--					  ,GV.[tip_codigo]
--					  ,GV.[veh_esbiendeuso]
--					  ,GV.[veh_estaenventa]
--					  ,GV.[veh_precio_venta]
--					  ,GV.[veh_fecha_def_precio]
--					  ,GV.[veh_estado]
--					  ,GV.[ef_codigo]
--					  ,GV.[veh_descripcion_fiscal]
--					  ,GV.[veh_fecha_compra]
--					  ,GV.[veh_fecha_fin_garantia]
--					  ,GV.[veh_fecha_ini_garantia]
--					  ,GV.[veh_fecha_venta]
				FROM [TechCoreDB].[dbo].[GEN_VEHICULOS] AS GV
					INNER JOIN (SELECT * 
								FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
								) AS EC ON
									GV.[emp_codigo] = EC.[empr_codigo]
					INNER JOIN (SELECT * 
								FROM [TechCoreDB].[dbo].[GEN_MARCAS]
								) AS MC ON
									GV.[emp_codigo] = MC.[emp_codigo]
										AND
									GV.[mar_codigo] = MC.[mar_codigo]
					INNER JOIN (SELECT * 
								FROM [TechCoreDB].[dbo].[GEN_MODELOS]
								) AS MD ON
									GV.[emp_codigo] = MD.[emp_codigo]
										AND
									GV.[mar_codigo] = MD.[mar_codigo]
										AND
									GV.[mod_codigo] = MD.[mod_codigo]
					INNER JOIN (SELECT * 
								FROM [TechCoreDB].[dbo].[GEN_SUBMODELOS]
								) AS SM ON
									GV.[emp_codigo] = SM.[emp_codigo]
										AND
									GV.[mod_codigo] = SM.[mod_codigo]
										AND
									GV.[smo_codigo] = SM.[smo_codigo]
					) AS VH ON
							RG.[veh_codigo] = VH.[veh_codigo]
WHERE [odr_codigo] = '1102133'


-- DETALLE DE LOS RECURSOS DE GARANT�A
SELECT TOP 10 RD.*
FROM [TechCoreDB].[dbo].[TAL_DETALLE_RECURSO] AS RD
	INNER JOIN (SELECT TOP 10 *
				FROM [TechCoreDB].[dbo].[TAL_RECURSOS]
				WHERE [odr_codigo] = '1102133'
				) AS RG ON
		RD.[rec_codigo] = RG.[rec_codigo]




-- AGRUPACI�N DE LA MANO DE OBRA DE LOS INCIDENTES
SELECT TOP 10000 RD.[mo_codigo]
	  ,MO.[mo_descripcion]
	  ,MO.[tmo_descripcion]
	  ,COUNT(*) AS TOTAL
SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_DETALLE_RECURSO] AS RD
	INNER JOIN (SELECT TOP 10 *, VH.*
				FROM [TechCoreDB].[dbo].[TAL_RECURSOS] RG
					INNER JOIN (SELECT EC.[empr_nombre]
									  ,GV.[emp_codigo]
									  ,GV.[veh_codigo]	
									  ,GV.[mar_codigo]
									  ,MC.[mar_nombre]
									  ,GV.[mod_codigo]
									  ,MD.[mod_nombre]
									  ,GV.[smo_codigo]
									  ,SM.[smo_modfFabrica]
									  ,SM.[smo_nombre]
									  ,LEFT(GV.[veh_nro_motor],3) AS TipMotor
								FROM [TechCoreDB].[dbo].[GEN_VEHICULOS] AS GV
									INNER JOIN (SELECT * 
												FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
												) AS EC ON
													GV.[emp_codigo] = EC.[empr_codigo]
									INNER JOIN (SELECT * 
												FROM [TechCoreDB].[dbo].[GEN_MARCAS]
												) AS MC ON
													GV.[emp_codigo] = MC.[emp_codigo]
														AND
													GV.[mar_codigo] = MC.[mar_codigo]
									INNER JOIN (SELECT * 
												FROM [TechCoreDB].[dbo].[GEN_MODELOS]
												) AS MD ON
													GV.[emp_codigo] = MD.[emp_codigo]
														AND
													GV.[mar_codigo] = MD.[mar_codigo]
														AND
													GV.[mod_codigo] = MD.[mod_codigo]
									INNER JOIN (SELECT * 
												FROM [TechCoreDB].[dbo].[GEN_SUBMODELOS]
												) AS SM ON
													GV.[emp_codigo] = SM.[emp_codigo]
														AND
													GV.[mod_codigo] = SM.[mod_codigo]
														AND
													GV.[smo_codigo] = SM.[smo_codigo]
									) AS VH ON
											RG.[veh_codigo] = VH.[veh_codigo]
				) AS RG ON
			RD. = RG.



	INNER JOIN (SELECT [tir_codigo]
						  ,[emp_codigo]
						  ,[suc_codigo]
						  ,[rec_codigo]
						  ,[inc_codigo]
						  ,[inc_descripcion]
					FROM [TechCoreDB].[dbo].[TAL_INCIDENTES_RECURSOS]
					) AS ICD ON
			RD.[emp_codigo] = ICD.[emp_codigo]
				AND
			RD.[suc_codigo] = ICD.[suc_codigo]
				AND
			RD.[rec_codigo] = ICD.[rec_codigo]
				AND
			RD.[inc_codigo] = ICD.[inc_codigo]
	INNER JOIN (SELECT MO.[emp_codigo]
						  ,MO.[mo_codigo]
						  ,MO.[mo_descripcion]
						  ,MO.[tmo_codigo]
						  ,TMO.[tmo_descripcion]
						  ,MO.[mo_observacion]
						  ,MO.[mo_fecha_alta]
						  ,MO.[mo_estado]
						  ,MO.[mo_alistaje]
					  FROM [TechCoreDB].[dbo].[TAL_MANO_OBRA] AS MO 
						INNER JOIN (SELECT [emp_codigo]
										  ,[tmo_codigo]
										  ,[tmo_descripcion]
										  ,[tmo_observacion]
										  ,[tmo_fecha_alta]
										  ,[tmo_estado]
									  FROM [TechCoreDB].[dbo].[TAL_TIPO_MANO_OBRA]) AS TMO ON
							MO.[emp_codigo] = TMO.[emp_codigo]
								AND
							MO.[tmo_codigo] = TMO.[tmo_codigo]
					) AS MO ON
			RD.[emp_codigo] = MO.[emp_codigo]
				AND
			RD.[mo_codigo] = MO.[mo_codigo]
WHERE RD.[tipo_detalle_codigo] = 1
GROUP BY RD.[mo_codigo]
		  ,MO.[mo_descripcion]
		  ,MO.[tmo_descripcion]
ORDER BY COUNT(*) DESC



-- DETALLE DE LA COMPOSICI�N DE CADA INCIDENTE
SELECT TOP 100 RD.[rec_codigo]
--	  ,RD.[emp_codigo]
--      ,RD.[suc_codigo]
      ,RD.[inc_codigo]
	  ,ICD.[inc_descripcion]
      ,RD.[der_codigo]
--      ,RD.[tipo_detalle_codigo]
      ,RD.[mo_codigo]
	  ,MO.[mo_descripcion]
	  ,MO.[tmo_descripcion]
--      ,RD.[pie_codigo]
--      ,RD.[der_descripcion]
      ,RD.[der_cantidad]
      ,RD.[der_importe]
--      ,RD.[val_codigo]
--      ,RD.[pro_codigo]
--      ,RD.[fal_codigo]
--      ,RD.[der_codigo_proveedor]
--      ,RD.[der_pieza_causa]
--      ,RD.[der_anomalia]
--      ,RD.[der_posicion]
--      ,RD.[der_observaciones]
--      ,RD.[der_nro_envio]
--      ,RD.[der_tipo_garantia]
--      ,RD.[der_mvs]
--      ,RD.[deo_codigo]
--      ,RD.[der_cantidad_reconocida]
--      ,RD.[der_tipo_pieza]
FROM [TechCoreDB].[dbo].[TAL_DETALLE_RECURSO] AS RD
	INNER JOIN (SELECT [tir_codigo]
					  ,[emp_codigo]
					  ,[suc_codigo]
					  ,[rec_codigo]
					  ,[inc_codigo]
					  ,[inc_descripcion]
				FROM [TechCoreDB].[dbo].[TAL_INCIDENTES_RECURSOS]
				) AS ICD ON
		RD.[emp_codigo] = ICD.[emp_codigo]
			AND
		RD.[suc_codigo] = ICD.[suc_codigo]
			AND
		RD.[rec_codigo] = ICD.[rec_codigo]
			AND
		RD.[inc_codigo] = ICD.[inc_codigo]
	INNER JOIN (SELECT MO.[emp_codigo]
					  ,MO.[mo_codigo]
					  ,MO.[mo_descripcion]
					  ,MO.[tmo_codigo]
					  ,TMO.[tmo_descripcion]
					  ,MO.[mo_observacion]
					  ,MO.[mo_fecha_alta]
					  ,MO.[mo_estado]
					  ,MO.[mo_alistaje]
				  FROM [TechCoreDB].[dbo].[TAL_MANO_OBRA] AS MO 
					INNER JOIN (SELECT [emp_codigo]
									  ,[tmo_codigo]
									  ,[tmo_descripcion]
									  ,[tmo_observacion]
									  ,[tmo_fecha_alta]
									  ,[tmo_estado]
								  FROM [TechCoreDB].[dbo].[TAL_TIPO_MANO_OBRA]) AS TMO ON
						MO.[emp_codigo] = TMO.[emp_codigo]
							AND
						MO.[tmo_codigo] = TMO.[tmo_codigo]
				) AS MO ON
		RD.[emp_codigo] = MO.[emp_codigo]
			AND
		RD.[mo_codigo] = MO.[mo_codigo]
WHERE RD.[mo_codigo] = 851
ORDER BY RD.[rec_codigo], RD.[inc_codigo]




 AND 

RD.[inc_codigo] = 103548
RD.[inc_codigo] = 103547
RD.[rec_codigo] = 49214




SELECT TOP 10 RIC.*
FROM [TechCoreDB].[dbo].[TAL_INCIDENTES_RECURSOS] AS RIC
WHERE [inc_codigo] = 103548 or [inc_codigo] = 103547

SELECT TOP 10 RIC.*
FROM [TechCoreDB].[dbo].[TAL_INCIDENTES_RECURSOS] AS RIC
	INNER JOIN (SELECT RD.[rec_codigo], RD.[inc_codigo]
				FROM [TechCoreDB].[dbo].[TAL_DETALLE_RECURSO] AS RD
					INNER JOIN (SELECT *
								FROM [TechCoreDB].[dbo].[TAL_RECURSOS]
								WHERE [odr_codigo] = '1102133'
								) AS RG ON
						RD.[rec_codigo] = RG.[rec_codigo]
				GROUP BY RD.[rec_codigo], RD.[inc_codigo]
				) AS RD ON
		RIC.[rec_codigo] = RD.[rec_codigo]
			AND
		RIC.[inc_codigo] = RD.[inc_codigo]


-- DETALLE DE LAS PIEZAS
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[REP_PIEZAS]
WHERE [pie_codigo] = 31024 OR [pie_codigo] = 28957




-- Informaci�n en detalle de todos los veh�culos
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_VEHICULOS]
WHERE [veh_codigo] = 127831


SELECT TOP 100 MO.[emp_codigo]
      ,MO.[mo_codigo]
      ,MO.[mo_descripcion]
      ,MO.[tmo_codigo]
	  ,TMO.[tmo_descripcion]
      ,MO.[mo_observacion]
      ,MO.[mo_fecha_alta]
      ,MO.[mo_estado]
      ,MO.[mo_alistaje]
  FROM [TechCoreDB].[dbo].[TAL_MANO_OBRA] AS MO 
	INNER JOIN (SELECT [emp_codigo]
					  ,[tmo_codigo]
					  ,[tmo_descripcion]
					  ,[tmo_observacion]
					  ,[tmo_fecha_alta]
					  ,[tmo_estado]
				  FROM [TechCoreDB].[dbo].[TAL_TIPO_MANO_OBRA]) AS TMO ON
		MO.[emp_codigo] = TMO.[emp_codigo]
			AND
		MO.[tmo_codigo] = TMO.[tmo_codigo]
WHERE [mo_codigo] = 351 OR [mo_codigo] = 3465




SELECT TOP 10 *, VH.*
FROM [TechCoreDB].[dbo].[TAL_RECURSOS] RG
	INNER JOIN (SELECT EC.[empr_nombre]
					  ,GV.[emp_codigo]
					  ,GV.[veh_codigo]	
					  ,GV.[mar_codigo]
					  ,MC.[mar_nombre]
					  ,GV.[mod_codigo]
					  ,MD.[mod_nombre]
					  ,GV.[smo_codigo]
					  ,SM.[smo_modfFabrica]
					  ,SM.[smo_nombre]
					  ,LEFT(GV.[veh_nro_motor],3) AS TipMotor
				FROM [TechCoreDB].[dbo].[GEN_VEHICULOS] AS GV
					INNER JOIN (SELECT * 
								FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
								) AS EC ON
									GV.[emp_codigo] = EC.[empr_codigo]
					INNER JOIN (SELECT * 
								FROM [TechCoreDB].[dbo].[GEN_MARCAS]
								) AS MC ON
									GV.[emp_codigo] = MC.[emp_codigo]
										AND
									GV.[mar_codigo] = MC.[mar_codigo]
					INNER JOIN (SELECT * 
								FROM [TechCoreDB].[dbo].[GEN_MODELOS]
								) AS MD ON
									GV.[emp_codigo] = MD.[emp_codigo]
										AND
									GV.[mar_codigo] = MD.[mar_codigo]
										AND
									GV.[mod_codigo] = MD.[mod_codigo]
					INNER JOIN (SELECT * 
								FROM [TechCoreDB].[dbo].[GEN_SUBMODELOS]
								) AS SM ON
									GV.[emp_codigo] = SM.[emp_codigo]
										AND
									GV.[mod_codigo] = SM.[mod_codigo]
										AND
									GV.[smo_codigo] = SM.[smo_codigo]
					) AS VH ON
							RG.[veh_codigo] = VH.[veh_codigo]
WHERE [odr_codigo] = '1102133'
SELECT PIEDET.[pie_codigo]
	,PIEDET.[pie_numero]
	,PIEDET.[pie_nombre]
	,PIEDET.[mar_nombre]
	,PIEDET.[mod_nombre]
	,PIEDET.[smo_nombre]
	,PIEDET.[TAL_MOD_NOMBRE]
	,PIEDET.[TAL_MOT_DESC]
	,COUNT(*) AS TOTAL
FROM (SELECT EMP.[empr_nombre]
		--	  ,VALD.[emp_codigo]
			  ,SUC.[suc_nombre]      
		--	  ,VALD.[suc_codigo]
			  ,VALD.[dva_codigo]
			  ,VALD.[dva_fecha]
			  ,VALD.[val_codigo]
			  ,VALD.[pie_codigo]
			  ,PIE.[pie_numero]
			  ,PIE.[pie_nombre]
			  ,VALD.[dva_cantidad]
			  ,VALD.[dva_accion]
			  ,VALD.[dva_precio]
			  ,VALD.[deo_codigo]
			  ,VALD.[empl_codigo]
			  ,VALD.[mec_codigo]
			  ,ODRDAT.[odr_codigo]
			  ,ODRDAT.[odr_fecha_aper]
			  ,ODRDAT.[mar_nombre]
			  ,ODRDAT.[mod_nombre]
			  ,ODRDAT.[smo_nombre]
			  ,ODRDAT.[TAL_MOD_NOMBRE]
			  ,ODRDAT.[TAL_MOT_DESC]
			  ,ODRDAT.[veh_a�o_fab]
		  FROM [TechCoreDB].[dbo].[REP_DETALLE_VALES] AS VALD
			INNER JOIN (SELECT * 
						FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
						) AS EMP ON
							VALD.[emp_codigo] = EMP.[empr_codigo]
			INNER JOIN (SELECT *  
						FROM [TechCoreDB].[dbo].[GEN_SUCURSALES]
						) AS SUC ON
							VALD.[emp_codigo] = SUC.[emp_codigo]
								AND
							VALD.[suc_codigo] = SUC.[suc_codigo]
			LEFT OUTER JOIN (SELECT * 
							 FROM [TechCoreDB].[dbo].[REP_PIEZAS]
							 ) AS PIE ON
								VALD.[emp_codigo] = PIE.[emp_codigo]
									AND
								VALD.[pie_codigo] = PIE.[pie_codigo]
			INNER JOIN (SELECT EMP.[empr_nombre]
							  ,ODRD.[emp_codigo]
							  ,SUC.[suc_nombre]
						--      ,ODRD.[suc_codigo]
							  ,ODRD.[odr_codigo]
							  ,ODRG.[odr_fecha_aper]
							  ,ODRD.[deo_codigo]
							  ,ODRD.[inc_codigo]
						--      ,ODRD.[deo_tde_codigo]
						--      ,ODRD.[mo_codigo]
						--      ,ODRD.[pro_codigo]
							  ,ODRD.[pie_codigo_solic]	--Solo es lo solicitado por orlando, no son los vales.
							  ,PIE.[pie_numero]
							  ,ODRD.[deo_descrip_pieza_solic]
							  ,PIE.[pie_nombre]
							  ,ODRD.[deo_cantidad_solic]
							  ,ODRD.[car_codigo]
							  ,ODRD.[deo_pieza_estado]
							  ,ODRD.[depre_pieza_movimiento]
							  ,ODRD.[deo_fecha_estimada_entrega]
							  ,ODRD.[depre_fecha_pieza_recep]
							  ,ODRD.[deo_observacion]
							  ,ODRD.[deo_cantidad]
							  ,ODRD.[deo_importe]
							  ,ODRD.[deo_bonificacion]
							  ,ODRD.[cal_item_id]
							  ,ODRD.[cal_monto_item]
							  ,ODRD.[cal_nro_factura]
							  ,ODRD.[descripcion_generica]
							  ,ODRD.[empl_codigo]
							  ,ODRG.[mar_nombre]
							  ,ODRG.[mar_codigo]
							  ,ODRG.[mod_nombre]
							  ,ODRG.[smo_nombre]
							  ,ODRG.[TAL_MOD_NOMBRE]
							  ,ODRG.[TAL_MOT_DESC]
							  ,ODRG.[veh_dominio]
							  ,ODRG.[veh_a�o_fab]
						  FROM [TechCoreDB].[dbo].[TAL_DETALLE_ODR] AS ODRD
							INNER JOIN (SELECT * 
										FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
										) AS EMP ON
											ODRD.[emp_codigo] = EMP.[empr_codigo]
							INNER JOIN (SELECT *  
										FROM [TechCoreDB].[dbo].[GEN_SUCURSALES]
										) AS SUC ON
											ODRD.[emp_codigo] = SUC.[emp_codigo]
												AND
											ODRD.[suc_codigo] = SUC.[suc_codigo]
							LEFT OUTER JOIN (SELECT * 
										FROM [TechCoreDB].[dbo].[REP_PIEZAS]
										) AS PIE ON
											ODRD.[emp_codigo] = PIE.[emp_codigo]
												AND
											ODRD.[pie_codigo_solic] = PIE.[pie_codigo]	
							INNER JOIN (SELECT EMP.[empr_nombre]
											  ,ODR.[emp_codigo]
											  ,SUC.[suc_nombre]
											  ,ODR.[suc_codigo]
											  ,ODR.[odr_codigo]
											  ,ODR.[tal_codigo]
											  ,ODR.[odr_tipo]
											  ,ODR.[veh_codigo]
											  ,ODR.[cli_codigo]
										--      ,ODR.[cli_codigo_Facturar]
											  ,ODR.[odr_quien_deja]
										--      ,ODR.[odr_quien_retira]
										--      ,ODR.[pre_codigo_genera]
										--      ,ODR.[pre_codigo_cancela]
											  ,ODR.[odr_estado_padre]
											  ,ODR.[odr_estado_hijo]
											  ,ODR.[odr_fecha_aper]
										--      ,ODR.[odr_fecha_entrega_est]
										--      ,ODR.[rol_codigo]
										--      ,ODR.[empl_codigo]
										--      ,ODR.[odr_cono]
											  ,ODR.[odr_kilometro]
										--      ,ODR.[odr_combustible]
										--      ,ODR.[odr_rueda_auxv]
										--      ,ODR.[odr_matafuego]
										--      ,ODR.[odr_baliza]
										--      ,ODR.[odr_estereo]
										--      ,ODR.[odr_alarma]
										--      ,ODR.[odr_unidad_parada]
										--      ,ODR.[odr_observacion_receptor]
										--      ,ODR.[odr_prioridad]
										--      ,ODR.[odr_retiro_Veh]
											  ,ODR.[odr_fecha_entrega_real]
										--      ,ODR.[odr_codigo_odr]
										--      ,ODR.[odr_observacion_taller]
										--      ,ODR.[odr_lavado]
										--      ,ODR.[odr_vehiculo_taller]
										--      ,ODR.[odr_caracter_urgencia]
										--      ,ODR.[odr_precio_estimado]
												,MMM.[mar_nombre]
												,MMM.[mar_codigo]
												,MMM.[mod_nombre]
												,MMM.[smo_nombre]
												,MMM.[TAL_MOD_NOMBRE]
												,MMM.[TAL_MOT_DESC]
												,MMM.[veh_dominio]
												,MMM.[veh_a�o_fab]
												,MMM.[veh_fecha_fin_garantia]
												,MMM.[veh_fecha_ini_garantia]
												,MMM.[veh_fecha_venta]
										  FROM [TechCoreDB].[dbo].[TAL_ORDENES_REPARACION] AS ODR
											INNER JOIN (SELECT * 
														FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
														) AS EMP ON
															ODR.[emp_codigo] = EMP.[empr_codigo]
											INNER JOIN (SELECT *  
														FROM [TechCoreDB].[dbo].[GEN_SUCURSALES]
														) AS SUC ON
															ODR.[emp_codigo] = SUC.[emp_codigo]
																AND
															ODR.[suc_codigo] = SUC.[suc_codigo]
											INNER JOIN (SELECT EMP.[empr_nombre]
														,VEH.[emp_codigo]
														,VEH.[mar_codigo]
														,VEH.[veh_codigo]
														,MARC.[mar_nombre]
														,VEH.[mod_codigo]
														,MOD.[mod_nombre]
														,VEH.[smo_codigo]
														,SMOD.[smo_nombre]
														,EQUI.[tal_modelo]
														,EQUI.[TAL_MOD_NOMBRE]
														,EQUI.[tipo_motor_codigo]
														,EQUI.[TAL_MOT_DESC]
														,VEH.[veh_dominio]
													--	,VEH.[veh_nro_vin]
													--	,VEH.[veh_serie]
													--	,VEH.[veh_nro_motor]
													--	,VEH.[veh_chasis]
													--	,VEH.[veh_marcachasis]
													--	,VEH.[veh_marcamotor]
													--	,VEH.[col_codigo]
													--	,VEH.[veh_concesionaria]
														,VEH.[veh_a�o_fab]
													--	,VEH.[veh_kilometraje]
													--	,VEH.[ubi_codigo]
													--	,VEH.[veh_placa_oval]
														,VEH.[veh_sucursal]
														,SUC.[suc_nombre]
													--	,VEH.[veh_certificado]
													--	,VEH.[veh_fecha_certificado]
														,VEH.[veh_tipo_motor]
														,VEH.[veh_usado_nuevo]
														,VEH.[veh_nacional_importado]
														,VEH.[veh_observaciones]
													--	,VEH.[tip_codigo]
													--	,VEH.[veh_esbiendeuso]
													--	,VEH.[veh_estaenventa]
													--	,VEH.[veh_precio_venta]
													--	,VEH.[veh_fecha_def_precio]
													--	,VEH.[veh_estado]
													--	,VEH.[ef_codigo]
													--	,VEH.[veh_descripcion_fiscal]
													--	,VEH.[veh_fecha_compra]
														,VEH.[veh_fecha_fin_garantia]
														,VEH.[veh_fecha_ini_garantia]
														,VEH.[veh_fecha_venta]
													FROM [TechCoreDB].[dbo].[GEN_VEHICULOS] AS VEH
														INNER JOIN (SELECT * 
																	FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
																	) AS EMP ON
																		VEH.[emp_codigo] = EMP.[empr_codigo]
														INNER JOIN (SELECT *  
																	FROM [TechCoreDB].[dbo].[GEN_SUCURSALES]
																	) AS SUC ON
																		VEH.[emp_codigo] = SUC.[emp_codigo]
																			AND
																		VEH.[veh_sucursal] = SUC.[suc_codigo]
														INNER JOIN (SELECT * 
																	FROM [TechCoreDB].[dbo].[GEN_MARCAS]
																	) AS MARC ON
																		VEH.[emp_codigo] = MARC.[emp_codigo]
																			AND
																		VEH.[mar_codigo] = MARC.[mar_codigo]
														INNER JOIN (SELECT * 
																	FROM [TechCoreDB].[dbo].[GEN_MODELOS]
																	) AS MOD ON
																		VEH.[emp_codigo] = MOD.[emp_codigo]
																			AND
																		VEH.[mar_codigo] = MOD.[mar_codigo]
																			AND
																		VEH.[mod_codigo] = MOD.[mod_codigo]
														INNER JOIN (SELECT * 
																	FROM [TechCoreDB].[dbo].[GEN_SUBMODELOS]
																	) AS SMOD ON
																		VEH.[emp_codigo] = SMOD.[emp_codigo]
																			AND
																		VEH.[mod_codigo] = SMOD.[mod_codigo]
																			AND
																		VEH.[smo_codigo] = SMOD.[smo_codigo]
														INNER JOIN (SELECT EQI.*, TMOD.[talmod_nombre] AS TAL_MOD_NOMBRE, TTMOT.[descripcion] AS TAL_MOT_DESC
																	FROM [TechCoreDB].[dbo].[TAL_EQUIVALENCIAS] AS EQI
																		INNER JOIN (SELECT *
																					FROM [TechCoreDB].[dbo].[TAL_TIPO_MOTOR]
																					)  AS TTMOT ON
																					EQI.[emp_codigo] = TTMOT.[emp_codigo]
																						AND
																					EQI.[mar_codigo] = TTMOT.[mar_codigo]
																						AND
																					EQI.[tipo_motor_codigo] = TTMOT.[tipo_motor_codigo]
																		INNER JOIN (SELECT * 
																					FROM [TechCoreDB].[dbo].[TAL_MODELOS]
																					)  AS TMOD ON
																					EQI.[emp_codigo] = TMOD.[emp_codigo]
																						AND
																					EQI.[mar_codigo] = TMOD.[mar_codigo]
																						AND
																					EQI.[tal_modelo] = TMOD.[talmod_codigo]
																	) AS EQUI ON
																		VEH.[emp_codigo] = EQUI.[emp_codigo]
																			AND
																		VEH.[mar_codigo] = EQUI.[mar_codigo]
																			AND
																		VEH.[mod_codigo] = EQUI.[mod_codigo]
																			AND
																		VEH.[smo_codigo] = EQUI.[smo_codigo]
														) AS MMM ON
															ODR.[veh_codigo] = MMM.[veh_codigo]) AS ODRG ON
																ODRD.[odr_codigo] = ODRG.[odr_codigo]
		--									WHERE ODRD.[odr_codigo] = '1099835'
						) AS ODRDAT ON
							VALD.[emp_codigo] = ODRDAT.[emp_codigo]
								AND
							VALD.[deo_codigo] = ODRDAT.[deo_codigo]
		WHERE VALD.[dva_accion] = 'Entregada'
--			AND ODRDAT.[odr_fecha_aper] >= '31/05/2012'
	) AS PIEDET
GROUP BY PIEDET.[pie_codigo]
	,PIEDET.[pie_numero]
	,PIEDET.[pie_nombre]
	,PIEDET.[mar_nombre]
	,PIEDET.[mod_nombre]
	,PIEDET.[smo_nombre]
	,PIEDET.[TAL_MOD_NOMBRE]
	,PIEDET.[TAL_MOT_DESC]


--ODRDAT.[odr_codigo] = '1099835'


-- Cantidad de Vales en el Sistema
--SELECT COUNT(*)
--FROM [TechCoreDB].[dbo].[REP_DETALLE_VALES] AS VALD

-- Indica las acciones de una pieza
--SELECT VALD.[dva_accion], COUNT(*)
--FROM [TechCoreDB].[dbo].[REP_DETALLE_VALES] AS VALD
--GROUP BY VALD.[dva_accion]
--dva_accion           
---------------------- -----------
--Entregada            94071
--Devuelta             2136


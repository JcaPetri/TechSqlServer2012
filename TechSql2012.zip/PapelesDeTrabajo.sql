-- Informaci�n de las Empresas
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
--empr_codigo empr_nombre                                        empr_descripcion                                                                                                                                                                                                                                                 empr_fecha_alta         empr_fecha_baja         empr_nro_concesionaria empr_tipo   empr_estado
------------- -------------------------------------------------- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------- ----------------------- ---------------------- ----------- -----------
--1           Turin                                              Turin                                                                                                                                                                                                                                                            NULL                    NULL                    NULL                   210         NULL
--2           Tagle                                              Tagle                                                                                                                                                                                                                                                            NULL                    NULL                    NULL                   210         NULL
--3           Aupesa                                             Aupesa                                                                                                                                                                                                                                                           NULL                    NULL                    NULL                   210         NULL
--4           Mediterraneo                                       Mediterraneo                                                                                                                                                                                                                                                     NULL                    NULL                    NULL                   210         NULL
--

-- Informaci�n de las Sucursales
SELECT TOP 100 * 
FROM [TechCoreDB].[dbo].[GEN_SUCURSALES]
--emp_codigo  suc_codigo  suc_nombre                                         suc_numero emp_nombre                                         suc_estado
------------- ----------- -------------------------------------------------- ---------- -------------------------------------------------- ----------
--1           11          Motcor-Cordoba                                     NULL       Motcor                                             A
--1           12          Motcor-Rio IV                                      NULL       Motcor                                             A
--1           13          Motcor-Villa Maria                                 NULL       Motcor                                             A
--2           21          Tagle-Cordoba                                      81900      Tagle                                              A
--2           22          Tagle-Rio IV                                       92100      Tagle                                              A
--2           23          Tagle-Villa Maria                                  NULL       Tagle                                              A
--4           41          Nix-Cordoba                                        NULL       Nix                                                A
--3           31          Avant-Cordoba                                      NULL       Avant                                              A
--3           32          Avant-Rio IV                                       NULL       Avant                                              A
--4           42          Nix-Rio IV                                         NULL       Nix                                                A


-- Informaci�n de las Marcas
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_MARCAS]
--emp_codigo  mar_codigo  mar_nombre                                         mar_descripcion                                                                                                                                                                                                                                                 mar_imagen                                                                                                                                                                                                                                                      mar_estado
------------- ----------- -------------------------------------------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------
--2           1           FIAT                                               FIAT                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            A
--2           2           RENAULT                                            RENAULT                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         A
--2           3           PEUGEOT                                            PEUGEOT                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         A


-- Informaci�n de las equivalencias 
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[TAL_EQUIVALENCIAS]
--equiv_codigo emp_codigo  mar_codigo  mod_codigo  smo_codigo  tal_modelo  tipo_motor_codigo
-------------- ----------- ----------- ----------- ----------- ----------- -----------------
--22           2 (Tagle)   2 (Renault) 3 (Clio)    17 (1.2 16V)31 (Clio)   2 (D4F)
--23           2           2           3 (ModCial) 18          31          2
--24           2           2           3           19          31          8
--25           2           2           4           20          4           21

-- Informaci�n de los modelos comerciales
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_MODELOS]
WHERE [mod_codigo] = 3
--emp_codigo  mod_codigo  mar_codigo  mod_nombre                                                                                           mod_descripcion                                                                                                                                                                                                                                                 tmo_codigo  mod_imagen                                                                                                                                                                                                                                                      mod_estado
------------- ----------- ----------- ---------------------------------------------------------------------------------------------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------
--2           1           2           CLIO 3 PTAS NAC (G08)                                                                                CLIO GAMA 2008 3 PUERTAS NACIONAL                                                                                                                                                                                                                               2           NULL                                                                                                                                                                                                                                                            A
--2           2           2           CLIO BIC NAC (G08)                                                                                   CLIO GAMA 2008 BICUERPO NACIONAL                                                                                                                                                                                                                                2           NULL                                                                                                                                                                                                                                                            A
--2           3           2           CLIO TRI NAC (G07)                                                                                   CLIO GAMA 2007 TRICUERPO NACIONAL                                                                                                                                                                                                                               2           NULL                                                                                                                                                                                                                                                            A
--2           4           2           SYMBOL                                                                                               SYMBOL                                                                                                                                                                                                                                                          2           NULL                                                                                                                                                                                                                                                            A

-- Informaci�n de los submodelos comerciales
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_SUBMODELOS]
WHERE [smo_codigo] = 17
--emp_codigo  smo_codigo  mod_codigo  smo_modfFabrica smo_nombre                                         smo_descripcion                                                                                      smo_estado tip_codigo  smo_certificado
------------- ----------- ----------- --------------- -------------------------------------------------- ---------------------------------------------------------------------------------------------------- ---------- ----------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--2           1           1           CB27  025       1.2 16v BASE                                       1.2 16v BASE                                                                                         A          0           NULL
--2           2           1           CB27  050       1.2 16v PACK                                       1.2 16v PACK                                                                                         A          0           NULL
--2           3           1           CB27  100       1.2 16v PACK PLUS                                  1.2 16v PACK PLUS                                                                                    A          0           NULL


-- Informaci�n de los Modelos del Taller
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[TAL_MODELOS]
WHERE [talmod_codigo] = 31
--emp_codigo  talmod_codigo mar_codigo  talmod_nombre  talmod_estado
------------- ------------- ----------- -------------- -------------
--2           4 (*)         2           SYMBOL         A
--2           5             2           SANDERO        A
--2           20            2           NUEVO MASTER   A
-- (*) esta es la clave para los modelos del taller


-- Informaci�n del tipo de motor, para cada
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[TAL_TIPO_MOTOR]
WHERE [tipo_motor_codigo] = 2
--emp_codigo  tipo_motor_codigo descripcion mar_codigo  tipo_motor_estado
------------- ----------------- ----------- ----------- -----------------
--2           2 (*)                D4F         2           A
--(*) CLAVE


-- Informaci�n del Tipo de motor por cada modelo del taller
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[TAL_TIPO_MOTOR_X_TAL_MODELOS]

--tipomotor_x_talmodelos emp_codigo  tipo_motor_codigo talmod_codigo
------------------------ ----------- ----------------- -------------
--6                      2           6                 20
--7                      2           1                 21
--8                      2           23                23
--12                     2           11                25
--13                     2           12                25
--14                     2           13                26
--15                     2           16                26


-- No tiene nada
--SELECT TOP 10 * 
--FROM [TechCoreDB].[dbo].[TAL_PIEZAS_ENTREGADAS]


-- Informaci�n de las piezas (esta es la lista de precios)
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[REP_PIEZAS]
WHERE [pie_codigo] = 11163
--emp_codigo  pie_codigo  pie_numero           pie_nombre                                         rub_codigo  pie_alicuota tpi_codigo  pie_precio_pagina                       pie_precio_vta_pub                      pie_numero_alternativo pie_unidad_empaque                                 pie_stock_minimo pie_stock_maximo pie_origen                                         pie_fecha_alta          pie_estado pie_vdm pie_fechacontrol        pie_stock_maximo_mostrador pie_stock_maximo_taller pie_stock_minimo_mostrador pie_stock_minimo_taller
------------- ----------- -------------------- -------------------------------------------------- ----------- ------------ ----------- --------------------------------------- --------------------------------------- ---------------------- -------------------------------------------------- ---------------- ---------------- -------------------------------------------------- ----------------------- ---------- ------- ----------------------- -------------------------- ----------------------- -------------------------- -----------------------
--2           1           0000000001           PRESUPUESTO                                        1           21           4           0.01                                    0.01                                                           88                                                 0                0                86                                                 2007-02-27 00:00:00.000 A          D       2009-08-01 00:00:00.000 0                          0                       0                          0
--2           2           0000000002           SUJETO A MODIFICACIO                               1           21           3           0.01                                    0.01                                    NULL                   88                                                 0                0                86                                                 2007-02-27 00:00:00.000 A          V       2009-08-01 00:00:00.000 0                          0                       0                          0
--2           3           0000000003           VALIDO POR 5 DIAS                                  1           21           3           0.01                                    0.01                                    NULL                   88                                                 0                0                86                                                 2007-02-27 00:00:00.000 A          V       2009-08-01 00:00:00.000 0                          0                       0                          0
--2           4           0000007              RELAY 70                                           1           21           14          21.00                                   21.00                                   NULL                   88                                                 0                0                86                                                 2007-10-04 00:00:00.000 A          V       2009-08-01 00:00:00.000 0                          0                       0                          0
--2           5           0000055406 I         MS 554-06                                          1           21           7           99.06                                   99.06                                   NULL                   88                                                 0                0                86                                                 2006-06-01 00:00:00.000 A          V       2009-08-01 00:00:00.000 0                          0                       0                          0
--2           6           0000057419 I         MOT.574.19                                         1           21           7           18.73                                   18.73                                   NULL                   88                                                 0                0                86                                                 2004-10-14 00:00:00.000 A          M       2009-08-01 00:00:00.000 0                          0                       0                          0

-- [pie_alicuota] = ALICUOTA IVA
SELECT TOP 100 [tpi_codigo], COUNT(*)
FROM [TechCoreDB].[dbo].[REP_PIEZAS]
GROUP BY [tpi_codigo]
ORDER BY [tpi_codigo]

-- ALICUOTAS DE DESCUENTOS DE RENAULT
SELECT TOP 100 [emp_codigo]
      ,[tpi_codigo]
      ,[tpi_nombre]
      ,[tpi_descripcion]
      ,[tpi_estado]
      ,[tpi_coeficiente]
      ,[tpi_descconce]
  FROM [TechCoreDB].[dbo].[REP_TIPO_PIEZA]
--emp_codigo  tpi_codigo  tpi_nombre                                         tpi_descripcion                                                                                      tpi_estado tpi_coeficiente                         tpi_descconce
------------- ----------- -------------------------------------------------- ---------------------------------------------------------------------------------------------------- ---------- --------------------------------------- ---------------------------------------
--2           1           A                                                  A                                                                                                    A          40.00                                   40.00
--4           1           A                                                  A                                                                                                    A          40.00                                   40.00
--2           2           B                                                  B                                                                                                    A          35.00                                   35.00
--4           2           B                                                  B                                                                                                    A          35.00                                   35.00
--2           3           C                                                  C                                                                                                    A          30.00                                   30.00
--4           3           C                                                  C                                                                                                    A          30.00                                   30.00


--SELECT TOP 10 count(*)
--FROM [TechCoreDB].[dbo].[REP_PIEZAS]
-- 32960


-- NO se usa
--SELECT TOP 10 * 
--FROM [TechCoreDB].[dbo].[REP_PIEZAS_COSTOS]

-- NO se usa
--SELECT TOP 10 * 
--FROM [TechCoreDB].[dbo].[REP_PIEZAS_HISTORIAL]


-- Stock Inicial
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[REP_PIEZAS_STOCK_INICIAL]
--emp_codigo  suc_codigo  pie_codigo  fecha_inicio            fecha_fin               stockinicial
------------- ----------- ----------- ----------------------- ----------------------- ------------
--2           21          1           2009-11-03 00:00:00.000 2013-11-03 00:00:00.000 0
--2           21          2           2009-11-03 00:00:00.000 2013-11-03 00:00:00.000 0


-- ESTA ES LA TABLA CON EL STOCK REAL
-- Detalle de las piezas por sucursal 
SELECT TOP 100 * 
FROM [TechCoreDB].[dbo].[REP_PIEZAS_SUCURSALES]
WHERE [pie_codigo] = 11163

--emp_codigo  suc_codigo  pie_codigo  pie_stock
------------- ----------- ----------- -----------
--2           21          1           0
--2           21          2           0
--2           21          3           0
--2           21          4           0



-- Dep�sitos Habilitados
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[REP_DEPOSITOS]
--emp_codigo  suc_codigo  dep_codigo  dep_nombre                                         dep_descripcion                                                                                                                                                                                                                                                 dep_estado
------------- ----------- ----------- -------------------------------------------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------
--2           21          1           Tagle                                              Dep�sito Tagle                                                                                                                                                                                                                                                  A
--2           21          2           Nissan                                             Dep�sito Nissan                                                                                                                                                                                                                                                 A
--2           22          1           Tagle Rio Cuarto                                   Tagle Rio Cuarto                                                                                                                                                                                                                                                A
--2           23          1           Tagle Villa Maria                                  Tagle Villa Maria                                                                                                                                                                                                                                               A
--4           41          1           Nissan C�rdoba                                     Dep�sito Nissan Cba                                                                                                                                                                                                                                             A
--4           42          1           Nissan Rio IV                                      Dep�sito Nissan Rio IV                                                                                                                                                                                                                                          A


-- Detalle de los Inventarios realizados
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[REP_INVENTARIOS]
--emp_codigo  suc_codigo  inv_codigo  inv_fecha_inicio        inv_fecha_fin           inv_estado inv_estado_empresa   inv_observacion
------------- ----------- ----------- ----------------------- ----------------------- ---------- -------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--2           21          54          2010-06-15 17:17:07.327 2010-06-15 17:17:07.327 A          173                  P
--2           21          64          2010-06-28 09:09:33.587 2010-06-28 09:09:33.587 A          173                  T
--2           21          65          2011-09-19 21:39:41.777 2011-09-19 21:39:41.777 A          173                  T
--2 (*)       21          66          2012-01-13 19:24:12.097 2012-01-14 23:24:53.420 A          173                  T
--2           22          1           2012-04-27 09:41:26.260 2012-04-28 17:09:44.500 A          173                  T
--(*) este es el �ltimo inventario realizado




-- Informaci�n de los Vales Retirados
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[REP_DETALLE_VALES] 
--emp_codigo  suc_codigo  dva_codigo  dva_fecha               val_codigo  pie_codigo  dva_cantidad dva_accion           dva_precio             deo_codigo  empl_codigo   mec_codigo
------------- ----------- ----------- ----------------------- ----------- ----------- ------------ -------------------- ---------------------- ----------- ------------- --------------------------------------------------
--2           21          1           2009-09-11 00:00:00.000 29026       23175       1            Entregada            591.9                  16          14678870      14678870
--2           21          2           2009-10-27 00:00:00.000 29034       23344       1            Entregada            45.18                  17          29472956      29472956
--2           21          3           2009-10-27 00:00:00.000 29034       3441        1            Entregada            224.85                 18          29472956      29472956
--2           21          4           2009-09-16 00:00:00.000 10359       3732        1            Entregada            173.08                 19          29105135      29105135



-- Informaci�n del inventario realizado
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[REP_PIEZASXINVENTARIO]
--emp_codigo  suc_codigo  pie_codigo  inv_codigo  pie_stock   pxi_estado
------------- ----------- ----------- ----------- ----------- ----------
--2           21          1           66          0           0
--2           21          2           66          0           0
--2           21          3           66          0           0
--2           21          4           66          0           0
--2           21          5           66          0           0
--en la empresa Tagle(2), Sucursal (21) Tagle Colon, Inventario de Enero (66).



-- NO SE
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[REP_ESTADOSXINVENTARIO]


SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_EMPLEADOS]

-- Cargos de Imputaci�n
SELECT TOP 100 [emp_codigo]
      ,[car_codigo]
      ,[car_nombre]
      ,[car_descripcion]
      ,[car_estado]
  FROM [TechCoreDB].[dbo].[GEN_CARGO]
--emp_codigo  car_codigo  car_nombre                                         car_descripcion                                                                                      car_estado
------------- ----------- -------------------------------------------------- ---------------------------------------------------------------------------------------------------- ----------
--1           1           Clientes                                                                                                                                                A
--1           2           Ventas                                                                                                                                                  A
--1           3           Taller Mecanico                                                                                                                                         A
--1           4           Taller Chapa y Pintura                                                                                                                                  A
--1           5           Repuestos                                                                                                                                               A
--1           6           Planes de Ahorro                                                                                                                                        A
--1           7           Usados                                                                                                                                                  A
--1           8           Garantias                                                                                                                                               A
--1           9           Gerencia                                                                                                                                                A
--1           10          Empleados                                                                                                                                               A
--

-- Informaci�n en detalle de todos los veh�culos
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_VEHICULOS]
WHERE [veh_codigo] = 127831

--emp_codigo  veh_codigo  mar_codigo  mod_codigo  smo_codigo  veh_dominio veh_nro_vin          veh_serie            veh_nro_motor        veh_chasis           veh_marcachasis veh_marcamotor col_codigo  veh_concesionaria                                  veh_a�o_fab veh_kilometraje                         ubi_codigo  veh_placa_oval                                                                                       veh_sucursal veh_certificado      veh_fecha_certificado   veh_tipo_motor veh_usado_nuevo veh_nacional_importado veh_observaciones                                                                                                                                                                                                                                               tip_codigo  veh_esbiendeuso veh_estaenventa veh_precio_venta                        veh_fecha_def_precio    veh_estado ef_codigo   veh_descripcion_fiscal                                                                                                                                                                                                                                          veh_fecha_compra        veh_fecha_fin_garantia  veh_fecha_ini_garantia  veh_fecha_venta
------------- ----------- ----------- ----------- ----------- ----------- -------------------- -------------------- -------------------- -------------------- --------------- -------------- ----------- -------------------------------------------------- ----------- --------------------------------------- ----------- ---------------------------------------------------------------------------------------------------- ------------ -------------------- ----------------------- -------------- --------------- ---------------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------- --------------- --------------- --------------------------------------- ----------------------- ---------- ----------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------- ----------------------- ----------------------- -----------------------
--2           116983      2           2           15          KQI-681     8A1BB2U01CL981674    L652121              D4FG728Q101163       8A1BB2U01CL981674    2               2              24                                                             2011        0                                       36                                                                                                               21                                NULL                    0              N               N                                                                                                                                                                                                                                                                                      3           0               0               0.00                                    NULL                    A          4           NULL                                                                                                                                                                                                                                                            NULL                    NULL                    NULL                    NULL




-- Clientes Consulta de Marketing
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[VISTACUBO_02_MKTTALLER]
WHERE [N� cliente] = '201034141'
--Empresa              A�o                            Mes                            N� cliente      Razon Social                                                                                         CALLE                                                                                                BARRIO                                             CP         Ciudad                                   Provincia                                Tel�fono                       Tel. laboral                   Celular                        Mail                                     Tipo documento                           N� documento CUIT                                     Fecha nacimiento Edad        Tipo cliente                                                                                                             Condicion fiscal               Marca                                              Modelo                                                                                               Submodelo                                          A�o fabricaci�n VIN                  ODR         Kilometraje                             Fecha apertura                 Precio estimado
---------------------- ------------------------------ ------------------------------ --------------- ---------------------------------------------------------------------------------------------------- ---------------------------------------------------------------------------------------------------- -------------------------------------------------- ---------- ---------------------------------------- ---------------------------------------- ------------------------------ ------------------------------ ------------------------------ ---------------------------------------- ---------------------------------------- ------------ ---------------------------------------- ---------------- ----------- ------------------------------------------------------------------------------------------------------------------------ ------------------------------ -------------------------------------------------- ---------------------------------------------------------------------------------------------------- -------------------------------------------------- --------------- -------------------- ----------- --------------------------------------- ------------------------------ ---------------------
--Tagle - C�rdoba      2012                           Junio                          201019651       YORIO DANIEL LEON EFRAIN                                                                             NOGAL HISTORICO 18 - B� SAN FRANCISCO                                                                                                                   5149       SALDAN                                   CORDOBA                                                                                                0351-156763778                 dlyorio@educ.ar                          D.N.I.                                   12244122     23122441229                              06/03/1958       54          General                                                                                                                  Consumidor Final               RENAULT                                            DUSTER                                                                                               PRIVILEGE 2.0 4X4/H79 4X4PRI/H79 4X4PRI/H79 4X4PRI 2011            93YHSR2S3CJ100764    1101742     6321                                    06/06/2012                     0.00
--Tagle - C�rdoba      2012                           Junio                          201019651       YORIO DANIEL LEON EFRAIN                                                                             NOGAL HISTORICO 18 - B� SAN FRANCISCO                                                                                                                   5149       SALDAN                                   CORDOBA                                                                                                0351-156763778                 dlyorio@educ.ar                          D.N.I.                                   12244122     23122441229                              06/03/1958       54          General                                                                                                                  Consumidor Final               RENAULT                                            DUSTER                                                                                               PRIVILEGE 2.0 4X4/H79 4X4PRI/H79 4X4PRI/H79 4X4PRI 2011            93YHSR2S3CJ100764    1101742     6321                                    06/06/2012                     0.00
--Tagle - C�rdoba      2012                           Junio                          201029366       CARRANZA FERNANDO DANIEL                                                                             PERNAMBUCO 559 B� VA ALL                                                                                                                                           VILLA ALLENDE                            CORDOBA                                                                                                0351-156859292                 NULL                                     D.N.I.                                   17456698                                              01/01/1980       32          General                                                                                                                  Consumidor Final               RENAULT                                            KANGOO 2 (G08)                                                                                       1.6 AUTH DA AA CD 1P                               2011            8A1KC1305CL137309    1102392     12000                                   01/06/2012                     0.00
--

SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_CLIENTES_VEHICULOS]

-- Clientes
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_CLIENTES_CONTACTOS]
WHERE [cli_codigo] = 201034141

emp_codigo  suc_codigo  cli_codigo      NombreApellido                                     Telefono
----------- ----------- --------------- -------------------------------------------------- --------------------------------------------------
2           21          201014090       JORGE GIRAUDO                                      0357315412731
2           21          6655            EDGAR WORTLEY                                      153223025
2           21          200001225       VIVIANA ESCLIPA  DANIEL COCONI                     0372215367132



-- Clientes Datos Adicionales
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_DATOS_ADICIONALES_CLIENTE]
WHERE [cli_codigo] = '201034141'
emp_codigo  cli_codigo                                         dac_tipo_uso    dac_trato dac_propietario dac_condicion_laboral dac_hijos   dac_aficion     dac_automovil
----------- -------------------------------------------------- --------------- --------- --------------- --------------------- ----------- --------------- -------------
2           200000290                                          Laboral         Sra       SI              Independiente         3           3               0
2           200003916                                                                                                          0                           1
2           200010371                                          Laboral         Sr        SI              Independiente         0                           1
2           200014569                                                                                                          0                           1
2           200017430                                          Laboral                                                         0                           1


-- VACIA
SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_DESTINATARIOS_MAIL]


SELECT TOP 10 * 
FROM [TechCoreDB].[dbo].[GEN_MAILS]




SELECT top 10 [emp_codigo]
      ,[cli_codigo]
      ,[dac_tipo_uso]
      ,[dac_trato]
      ,[dac_propietario]
      ,[dac_condicion_laboral]
      ,[dac_hijos]
      ,[dac_aficion]
      ,[dac_automovil]
  FROM [TechCoreDB].[dbo].[GEN_DATOS_ADICIONALES_CLIENTE]


-- TABLA VACIA
SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_RECLAMOS]


SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_DETALLE_PIEZAS_ODR]


-- TABLAS A DEFINIR QUE SON
SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_ANOMALIAS]
WHERE [odr_codigo] = '1105227'


SELECT TOP 10 *
--emp_codigo  mo_codigo_cabecera mo_codigo_detalle mar_codigo  mod_codigo  tipo_motor_codigo
FROM [TechCoreDB].[dbo].[TAL_DETALLE_MANO_OBRA]
WHERE [mo_codigo_cabecera] = 3465 OR [mo_codigo_cabecera] = 35


-- Detalle de los Presupuestos
SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_DETALLE_PRESUPUESTO]

-- Informaci�n de los recursos en garant�a
SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_RECURSOS]
WHERE [odr_codigo] = '1102133'

-- DETALLE DE LOS RECURSOS DE GARANT�A
SELECT TOP 10 RD.*
FROM [TechCoreDB].[dbo].[TAL_DETALLE_RECURSO] AS RD
	INNER JOIN (SELECT TOP 10 *
				FROM [TechCoreDB].[dbo].[TAL_RECURSOS]
				WHERE [odr_codigo] = '1102133'
				) AS RG ON
		RD.[rec_codigo] = RG.[rec_codigo]


SELECT TOP 10 RIC.*
FROM [TechCoreDB].[dbo].[TAL_INCIDENTES_RECURSOS] AS RIC
	INNER JOIN (SELECT RD.[rec_codigo], RD.[inc_codigo]
				FROM [TechCoreDB].[dbo].[TAL_DETALLE_RECURSO] AS RD
					INNER JOIN (SELECT *
								FROM [TechCoreDB].[dbo].[TAL_RECURSOS]
								WHERE [odr_codigo] = '1102133'
								) AS RG ON
						RD.[rec_codigo] = RG.[rec_codigo]
				GROUP BY RD.[rec_codigo], RD.[inc_codigo]
				) AS RD ON
		RIC.[rec_codigo] = RD.[rec_codigo]
			AND
		RIC.[inc_codigo] = RD.[inc_codigo]







-- Listado de Fallas
SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_FALLAS]


-- C�digos del Taller Mec�nico
SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_TALLER]



SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[]


SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[]


SELECT TOP 10 *
FROM [TechCoreDB].[dbo].[]




-- Detalle de los incidentes - Aqu� estan lo Incidentes que carga el receptor - MANIFESTACI�N DEL CLIENTE
select TOP 10 * 
FROM [TechCoreDB].[dbo].[TAL_INCIDENTES]
WHERE [doc_codigo] = '1105227'
--[doc_codigo] este es el c�digo de la odr

--emp_codigo  suc_codigo  Inc_codigo  Inc_numero  doc_codigo  doc_tipo tmo_codigo  Inc_descripcion                                                                                                                                                                                                                                                 car_codigo  empl_codigo                                        Inc_Tiempo_Est         Inc_hs_ini              Inc_hs_fin              Inc_estado                                         pre_confirmar                                      mar_codigo  mod_codigo  tipo_motor_codigo precio_estimado
------------- ----------- ----------- ----------- ----------- -------- ----------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------- -------------------------------------------------- ---------------------- ----------------------- ----------------------- -------------------------------------------------- -------------------------------------------------- ----------- ----------- ----------------- ---------------------
--2           21          161592      1           1104458     0        NULL        GNC 16M3 5TA GCION                                                                           VTA PAB                                                                                                                                                            1           23194250                                           0                      2012-07-18 11:16:38.757 2012-07-18 11:16:39.113 Finalizado                                         NULL                                               2           141         22                12760.00

-- Incidentes trabajados por los mec�nicos
select TOP 10 *
FROM [TechCoreDB].[dbo].[TAL_DETALLE_ODR]
WHERE [odr_codigo] = '1105227'

--emp_codigo  suc_codigo  deo_codigo  odr_codigo  inc_codigo  deo_tde_codigo mo_codigo   pro_codigo  pie_codigo_solic deo_descrip_pieza_solic                                                                                                                                                                                                                                         deo_cantidad_solic     car_codigo  deo_pieza_estado                                   depre_pieza_movimiento                             deo_fecha_estimada_entrega depre_fecha_pieza_recep deo_observacion                                                                                                                                                                                                                                                 deo_cantidad           deo_importe            deo_bonificacion       cal_item_id cal_monto_item         cal_nro_factura                      descripcion_generica                                                                                                                                                                                                                                            empl_codigo
------------- ----------- ----------- ----------- ----------- -------------- ----------- ----------- ---------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------- ----------- -------------------------------------------------- -------------------------------------------------- -------------------------- ----------------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------- ---------------------- ---------------------- ----------- ---------------------- ------------------------------------ --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--2           21          170764      1105227     164194      1              2796        0           NULL             NULL                                                                                                                                                                                                                                                            0                      1           NULL                                               Reparar                                            NULL                       NULL                    312                                                                                                                                                                                                                                                             0.35                   63                     NULL                   NULL        NULL                   NULL                                 NULL                                                                                                                                                                                                                                                            NULL
--2           21          170765      1105227     164194      1              2797        0           NULL             NULL                                                                                                                                                                                                                                                            0                      1           NULL                                               Reparar                                            NULL                       NULL                    312                                                                                                                                                                                                                                                             0.25                   59                     NULL                   NULL        NULL                   NULL                                 NULL                                                                                                                                                                                                                                                            NULL
--2           21          170766      1105227     164194      1              2798        0           NULL             NULL                                                                                                                                                                                                                                                            0                      1           NULL                                               Reparar                                            NULL                       NULL                    312                                                                                                                                                                                                                                                             0.7                    177.8                  NULL                   NULL        NULL                   NULL                                 NULL                                                                                                                                                                                                                                                            NULL
--2           21          170767      1105227     164194      1              2799        0           NULL             NULL                                                                                                                                                                                                                                                            0                      1           NULL                                               Reparar                                            NULL                       NULL                    312                                                                                                                                                                                                                                                             0.3                    88.5                   NULL                   NULL        NULL                   NULL                                 NULL                                                                                                                                                                                                                                                            NULL
--2           21          170778      1105227     164194      2              NULL        0           NULL             Filtro aceite                                                                                                                                                                                                                                                   1                      1           Entregado                                          Reparar                                            2012-08-01 08:28:29.083    NULL                    312                                                                                                                                                                                                                                                             1                      35.49                  NULL                   NULL        NULL                   NULL                                 NULL                                                                                                                                                                                                                                                            13984059
--2           21          170779      1105227     164194      2              NULL        0           NULL             Filtro aire                                                                                                                                                                                                                                                     1                      1           Entregado                                          Reparar                                            2012-08-01 08:28:29.083    NULL                    312                                                                                                                                                                                                                                                             1                      99.83                  NULL                   NULL        NULL                   NULL                                 NULL                                                                                                                                                                                                                                                            13984059
--2           21          170780      1105227     164194      2              NULL        0           NULL             Arandela de Tapon                                                                                                                                                                                                                                               1                      1           Entregado                                          Reparar                                            2012-08-01 08:28:29.083    NULL                    312                                                                                                                                                                                                                                                             1                      11.53                  NULL                   NULL        NULL                   NULL                                 NULL                                                                                                                                                                                                                                                            13984059
--2           21          170781      1105227     164198      2              NULL        0           NULL             Cola de escape                                                                                                                                                                                                                                                  1                      1           NULL                                               Reparar                                            NULL                       NULL                    312                                                                                                                                                                                                                                                             1                      0                      NULL                   NULL        NULL                   NULL                                 NULL                                                                                                                                                                                                                                                            13984059
--2           21          170782      1105227     164196      2              NULL        0           NULL             Dispositivo Air-Bag                                                                                                                                                                                                                                             1                      8           Pendiente Autorizacion                             Reparar                                            NULL                       NULL                    312                                                                                                                                                                                                                                                             1                      0                      NULL                   NULL        NULL                   NULL                                 NULL                                                                                                                                                                                                                                                            13984059
--
--'1104458'
--emp_codigo  suc_codigo  deo_codigo  odr_codigo  inc_codigo  deo_tde_codigo mo_codigo   pro_codigo  pie_codigo_solic deo_descrip_pieza_solic                                                                                                                                                                                                                                         deo_cantidad_solic     car_codigo  deo_pieza_estado                                   depre_pieza_movimiento                             deo_fecha_estimada_entrega depre_fecha_pieza_recep deo_observacion                                                                                                                                                                                                                                                 deo_cantidad           deo_importe            deo_bonificacion       cal_item_id cal_monto_item         cal_nro_factura                      descripcion_generica                                                                                                                                                                                                                                            empl_codigo
------------- ----------- ----------- ----------- ----------- -------------- ----------- ----------- ---------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------- ----------- -------------------------------------------------- -------------------------------------------------- -------------------------- ----------------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------- ---------------------- ---------------------- ----------- ---------------------- ------------------------------------ --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--2           21          167556      1104458     161592      3              2282        200001366   NULL             NULL                                                                                                                                                                                                                                                            1                      1           NULL                                               Reparar                                            NULL                       NULL                    NULL                                                                                                                                                                                                                                                            1                      10545.4545             NULL                   1           6417.36                44C6EC6C-CBEC-4488-B54E-C470420F6F47 NULL                                                                                                                                                                                                                                                            NULL


-- Detalle de los incidentes, Verlo
SELECT TOP 10 [emp_codigo]
      ,[suc_codigo]
      ,[tt_codigo]
      ,[inc_codigo]
      ,[tt_hs_inicio]
      ,[tt_hs_fin]
  FROM [TechCoreDB].[dbo].[TAL_TIEMPOS_MECANICO_INCIDENTE]
WHERE [inc_codigo] = '164194'
--emp_codigo  suc_codigo  tt_codigo   inc_codigo  tt_hs_inicio            tt_hs_fin
------------- ----------- ----------- ----------- ----------------------- -----------------------
--2           21          1           281         2009-11-04 10:25:35.017 2009-11-04 16:19:14.467
--2           21          2           283         2009-11-04 10:26:31.893 2009-11-06 13:21:11.317
--2           21          3           286         2009-11-04 10:37:52.490 2009-11-04 15:17:46.170
--2           21          4           267         2009-11-04 11:19:58.697 2009-11-04 14:51:10.677
--2           21          5           268         2009-11-04 11:44:08.640 2009-11-04 14:50:21.563
--2           21          6           269         2009-11-04 11:44:56.140 2009-11-04 14:52:04.443
--2           21          7           270         2009-11-04 11:45:07.733 2009-11-04 14:52:29.850
--2           21          8           272         2009-11-04 13:13:42.557 2009-11-04 17:45:29.460
--2           21          9           261         2009-11-04 15:51:32.050 2009-11-04 17:45:29.460
--2           21          10          282         2009-11-04 16:17:36.557 2009-11-04 18:54:50.810
--
--


select top 10 count(*) as total
FROM [TechCoreDB].[dbo].[TAL_ORDENES_REPARACION] 



--
--
--SELECT TOP 10 [emp_codigo]
--      ,[suc_codigo]
--      ,[idTechCore]
--      ,[origen]
--      ,[idComprobante]
--      ,[idComprobanteCalipso]
--      ,[modulo]
--      ,[estado]
--      ,[fecha_creacion]
--      ,[fecha_actualizacion]
--      ,[TimeStamp]
--      ,[tipo_comprobante]
--      ,[monto_comprobante]
--      ,[monto_iva]
--      ,[monto_descuento]
--      ,[cli_codigo]
--  FROM [TechCoreDB].[dbo].[GEN_COMPROBANTES]
--WHERE [idComprobante] = 1103020


--
--
---- DATOS DE LA FACTURACI�N
--SELECT TOP 10 [suc_codigo]
--      ,[emp_codigo]
--      ,[dco_codigo]
--      ,[idTechCore]
--      ,[pie_codigo]
--      ,[cant]
--      ,[precio]
--      ,[dre_codigo]
--      ,[costoReposicion]
--      ,[costoReal]
--      ,[precio_lista]
--  FROM [TechCoreDB].[dbo].[GEN_DETALLE_COMPROBANTES]
----WHERE [idTechCore] = 6



-- DATOS DE LA VENTA DE AUTOS
SELECT TOP 10 [id]
      ,[emp_codigo]
      ,[suc_codigo]
      ,[fecha_alta]
      ,[veh_codigo]
      ,[destinatario_codigo]
      ,[destinatario_nombre]
      ,[sol_codigo]
      ,[nombre_comprobante]
      ,[nro_comprobante]
      ,[fecha_comprobante]
      ,[tipo_transaccion_calipso]
      ,[tipo_transaccion_techcore]
      ,[total]
      ,[subtotal]
      ,[alicuota]
      ,[id_calipso]
  FROM [TechCoreDB].[dbo].[GEN_COMPROBANTES_VENTAS]
--WHERE [sol_codigo] = 79692
--id          emp_codigo  suc_codigo  fecha_alta              veh_codigo  destinatario_codigo destinatario_nombre                                                                                  sol_codigo  nombre_comprobante                                 nro_comprobante fecha_comprobante       tipo_transaccion_calipso                                     tipo_transaccion_techcore total                                   subtotal                                alicuota id_calipso
------------- ----------- ----------- ----------------------- ----------- ------------------- ---------------------------------------------------------------------------------------------------- ----------- -------------------------------------------------- --------------- ----------------------- ------------------------------------------------------------ ------------------------- --------------------------------------- --------------------------------------- -------- ------------------------------------
--1           2           21          2011-10-22 11:06:46.000 0           201001989           GOBIERNO DE LA PROVINCIA DE CORDOBA                                                                  8250        FacVta Nro.  004100028371 - Fecha 22-10-2011       B-004100028371  2011-10-22 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     108700.00                               98371.04                                10.50    69BB91FE-7B70-4FA2-8EFC-1D5DE0312F18
--2           2           21          2009-12-14 15:26:14.000 100000      200015661           ALVAREZ BOHLE  MARIA CECILIA                                                                         310         FacVta Nro.  004100021528 - Fecha 14-12-2009       B-004100021528  2009-12-14 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     48200.00                                39834.71                                21.00    DDE86F5B-E968-4E49-B929-D629B680B509
--3           2           21          2010-01-18 16:24:23.000 100001      200017223           SAYAVEDRA DARIO FERNANDO                                                                             613         FacVta Nro.  004100021753 - Fecha 18-01-2010       B-004100021753  2010-01-18 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     47100.00                                38925.62                                21.00    448CC90E-80F2-4DB6-8DD3-1E54C3D94A27
--4           2           21          2010-01-08 12:13:43.000 100002      200016863           PETRONE MARIA ANDREA                                                                                 527         FacVta Nro.  004100021683 - Fecha 08-01-2010       B-004100021683  2010-01-08 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     47300.00                                39090.91                                21.00    20BEC871-7AC6-4B4D-8C8E-E749CB87A205
--5           2           21          2009-12-16 10:26:50.000 100003      200015663           HILAL  JOSE HUMBERTO                                                                                 312         FacVta Nro.  004100021538 - Fecha 16-12-2009       B-004100021538  2009-12-16 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     56300.00                                50950.23                                10.50    257FE187-D610-49A8-989E-91E5569352DA
--6           2           21          2010-02-11 14:24:38.000 100004      200017319           AMATEIS DANIEL OMAR                                                                                  641         FacVta Nro.  006400000589 - Fecha 20-01-2010       B-006400000589  2010-01-20 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     47200.01                                39008.27                                21.00    62B47AD0-B918-47D3-82A3-07F2392623E3
--7           2           21          2010-01-30 10:15:38.000 100005      200017743           SCARAMELLINI BURGOS JUAN CARLOS                                                                      742         FacVta Nro.  004100021877 - Fecha 30-01-2010       B-004100021877  2010-01-30 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     45400.00                                37520.66                                21.00    A8B1D3CA-A0F5-481E-9278-2C68415EA7FC
--8           2           21          2009-12-10 17:37:43.000 100006      200015120           MONTOYA  GRACIELA EDITH                                                                              224         FacVta Nro.  004100021518 - Fecha 10-12-2009       B-004100021518  2009-12-10 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     47700.00                                39421.49                                21.00    1959FC14-EA17-4BAF-A200-606D9F11C27D
--9           2           21          2010-01-13 09:55:29.000 100007      200016992           RIOS PATRICIA MERCEDES                                                                               554         FacVta Nro.  004100021715 - Fecha 13-01-2010       B-004100021715  2010-01-13 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     45000.00                                37190.08                                21.00    CC34D96D-47BF-4236-8EA5-121645BB6650
--10          2           21          2009-11-23 17:28:01.000 100008      200014763           FIGUEROA ADRIANA DEL VALLE                                                                           137         FacVta Nro.  004100021416 - Fecha 23-11-2009       B-004100021416  2009-11-23 00:00:00.000 005 - Autos Okm Tagle                                        Venta                     46100.00                                38099.17                                21.00    3B83CF0B-0648-4069-AFEC-3BEA80A4FE20
--


SELECT EMP.[empr_nombre]
			  ,STK.[emp_codigo]
			  ,STKSUC.[dep_nombre]
			  ,STK.[suc_codigo]
			  ,STK.[pie_codigo]
			  ,PIE.[pie_numero]
			  ,PIE.[pie_nombre]
			  ,STK.[pie_stock]
			  ,CAST(CAST(PIE.[pie_precio_vta_pub] AS NUMERIC(18,2)) * (1 - CAST(PIE.[tpi_coeficiente] AS NUMERIC(18,2)) / 100) AS NUMERIC(18,2)) AS PNC
	 		  ,PIE.[pie_precio_vta_pub] AS PCL
			  ,PIE.[pie_alicuota] AS ALIC_IVA
			  ,CAST(CAST(PIE.[pie_precio_vta_pub] AS NUMERIC(18,2)) * (1 + CAST(PIE.[tpi_coeficiente] AS NUMERIC(18,2)) / 100) AS NUMERIC(18,2)) AS PCIVA
			  ,PIE.[tpi_codigo]
			  ,PIE.[tpi_nombre]
			  ,PIE.[tpi_coeficiente]
			  ,PIE.[pie_fecha_alta]
			  ,PIE.[pie_estado]
			  ,PIE.[pie_vdm]
			  ,PIE.[pie_stock_minimo]
			  ,PIE.[pie_stock_maximo]
FROM [TechCoreDB].[dbo].[REP_PIEZAS_SUCURSALES] AS STK
			INNER JOIN (SELECT * 
						FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
						) AS EMP ON
							STK.[emp_codigo] = EMP.[empr_codigo]
			INNER JOIN (SELECT *  
						FROM [TechCoreDB].[dbo].[REP_DEPOSITOS]
						WHERE dep_codigo = 1
						) AS STKSUC ON
							STK.[emp_codigo] = STKSUC.[emp_codigo]
								AND
							STK.[suc_codigo] = STKSUC.[suc_codigo]
			LEFT OUTER JOIN (SELECT PIEZ.* ,TPI.[tpi_nombre] ,TPI.[tpi_coeficiente]
							 FROM [TechCoreDB].[dbo].[REP_PIEZAS] AS PIEZ 
								LEFT OUTER JOIN (SELECT [emp_codigo]
													  ,[tpi_codigo]
													  ,[tpi_nombre]
													  ,[tpi_descripcion]
													  ,[tpi_estado]
													  ,[tpi_coeficiente]
													  ,[tpi_descconce]
												  FROM [TechCoreDB].[dbo].[REP_TIPO_PIEZA]
												 ) AS TPI ON
													PIEZ.[emp_codigo] = TPI.[emp_codigo]
														AND
													PIEZ.[tpi_codigo] = TPI.[tpi_codigo]
							 ) AS PIE ON
								STK.[emp_codigo] = PIE.[emp_codigo]
									AND
								STK.[pie_codigo] = PIE.[pie_codigo]
WHERE STK.[emp_codigo] = 2 AND STK.[suc_codigo] = 21
	AND PIE.[pie_estado] = 'A'
	  AND STK.[pie_stock] > 0



--	  AND PIE.[pie_numero] = '8671017505 I'
--
--			OR PIE.[pie_numero] = '7711238596 I'
--			OR PIE.[pie_numero] = '7700427646 I'
--			OR PIE.[pie_numero] = ''
--			OR PIE.[pie_numero] = '7700431819 I'

--	  AND STK.[pie_codigo] = 11163


SELECT TOP 10 PIEZ.* ,TPI.[tpi_nombre] ,TPI.[tpi_coeficiente]
 FROM [TechCoreDB].[dbo].[REP_PIEZAS] AS PIEZ 
	LEFT OUTER JOIN (SELECT [emp_codigo]
						  ,[tpi_codigo]
						  ,[tpi_nombre]
						  ,[tpi_descripcion]
						  ,[tpi_estado]
						  ,[tpi_coeficiente]
						  ,[tpi_descconce]
					  FROM [TechCoreDB].[dbo].[REP_TIPO_PIEZA]
					 ) AS TPI ON
						PIEZ.[emp_codigo] = TPI.[emp_codigo]
							AND
						PIEZ.[tpi_codigo] = TPI.[tpi_codigo]
WHERE [pie_estado] = 'E'

WHERE [pie_codigo] = 29455 or [pie_codigo] = 29644

--SELECT TOP 10 * 
--FROM [TechCoreDB].[dbo].[REP_PIEZAS]
--WHERE [pie_codigo] = 11163
--,rub_codigo
--,pie_numero_alternativo
--,pie_unidad_empaque
--,pie_origen
--,pie_fechacontrol
--,pie_stock_maximo_mostrador
--,pie_stock_maximo_taller
--,pie_stock_minimo_mostrador
--,pie_stock_minimo_taller

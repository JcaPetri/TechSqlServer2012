

-- LLEVA 2,34 MINUTOS
-- DATOS DE LAS ODR
SELECT TOP 100 EMP.[empr_nombre]
--	  ,char(9) AS '|'
--	  ,ODR.[emp_codigo]
--	  ,char(9) AS '|'
	  ,SUC.[suc_nombre]
--	  ,char(9) AS '|'
--      ,ODR.[suc_codigo]
--	  ,char(9) AS '|'
      ,ODR.[odr_codigo]
--	  ,char(9) AS '|'
--      ,ODR.[tal_codigo]
--	  ,char(9) AS '|'
--      ,ODR.[odr_tipo]
--	  ,char(9) AS '|'
      ,ODR.[cli_codigo]
--	  ,char(9) AS '|'
	  ,CLI.[Razon Social]
--	  ,char(9) AS '|'
	  ,CLI.Provincia
--	  ,char(9) AS '|'
	  ,CLI.Ciudad
--	  ,char(9) AS '|'
	  ,CLI.BARRIO
--	  ,char(9) AS '|'
	  ,CLI.CALLE
--	  ,char(9) AS '|'
	  ,CLI.CP
--	  ,char(9) AS '|'
	  ,CLI.Tel�fono
--	  ,char(9) AS '|'
	  ,CLI.[Tel. laboral]
--	  ,char(9) AS '|'
	  ,CLI.Celular
--	  ,char(9) AS '|'
	  ,CLI.Mail
--	  ,char(9) AS '|'
	  ,CLI.[Tipo documento]
--	  ,char(9) AS '|'
	  ,CLI.[N� documento]
--	  ,char(9) AS '|'
	  ,CLI.CUIT
--	  ,char(9) AS '|'
	  ,CLI.[Fecha nacimiento]
--	  ,char(9) AS '|'
	  ,CLI.Edad
--	  ,char(9) AS '|'
--	  ,CLI.[Tipo cliente]
--	  ,char(9) AS '|'
--      ,ODR.[cli_codigo_Facturar]
--	  ,char(9) AS '|'
--      ,ODR.[odr_quien_deja]
--	  ,char(9) AS '|'
--      ,ODR.[odr_quien_retira]
--      ,ODR.[pre_codigo_genera]
--      ,ODR.[pre_codigo_cancela]
--      ,ODR.[odr_estado_padre]
--	  ,char(9) AS '|'
--      ,ODR.[odr_estado_hijo]
--	  ,char(9) AS '|'
      ,ODR.[odr_fecha_aper]
--	  ,char(9) AS '|'
--      ,ODR.[odr_fecha_entrega_est]
--      ,ODR.[rol_codigo]
--      ,ODR.[empl_codigo]
--	  ,char(9) AS '|'
	  ,EPL.[NOMBRE]
--	  ,char(9) AS '|'
      ,ODR.[odr_cono]
--	  ,char(9) AS '|'
      ,ODR.[odr_kilometro]
--	  ,char(9) AS '|'
--      ,ODR.[odr_combustible]
--      ,ODR.[odr_rueda_auxv]
--      ,ODR.[odr_matafuego]
--      ,ODR.[odr_baliza]
--      ,ODR.[odr_estereo]
      ,ODR.[odr_alarma]
--	  ,char(9) AS '|'
--      ,ODR.[odr_unidad_parada]
--      ,ODR.[odr_observacion_receptor]
--	  ,char(9) AS '|'
--      ,ODR.[odr_prioridad]
--      ,ODR.[odr_retiro_Veh]
--      ,ODR.[odr_fecha_entrega_real]
--	  ,char(9) AS '|'
--      ,ODR.[odr_codigo_odr]
--      ,ODR.[odr_observacion_taller]
--	  ,char(9) AS '|'
--      ,ODR.[odr_lavado]
--      ,ODR.[odr_vehiculo_taller]
--      ,ODR.[odr_caracter_urgencia]
--      ,ODR.[odr_precio_estimado]
--	  ,char(9) AS '|'
--      ,ODR.[veh_codigo]
--	  ,char(9) AS '|'
	  ,MMM.[mar_nombre]
--	  ,char(9) AS '|'
	  ,MMM.[mod_nombre]
--	  ,char(9) AS '|'
--	  ,MMM.[smo_nombre]
--	  ,char(9) AS '|'
--	  ,MMM.[TAL_MOD_NOMBRE]
--	  ,char(9) AS '|'
	  ,MMM.[TAL_MOT_DESC]
--	  ,char(9) AS '|'
	  ,MMM.[veh_dominio]
--	  ,char(9) AS '|'
--	  ,MMM.[veh_a�o_fab]
--	  ,char(9) AS '|'
--	  ,MMM.[veh_nro_vin]
--	  ,char(9) AS '|'
--	  ,MMM.[veh_serie]
--	  ,char(9) AS '|'
--	  ,MMM.[veh_fecha_fin_garantia]
--	  ,char(9) AS '|'
--	  ,MMM.[veh_fecha_ini_garantia]
--	  ,char(9) AS '|'
--	  ,MMM.[veh_fecha_venta]
--	  ,char(9) AS '|'
--	  ,MMM.[veh_observaciones]
  FROM [TechCoreDB].[dbo].[TAL_ORDENES_REPARACION] AS ODR
	INNER JOIN (SELECT * 
				FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
				) AS EMP ON
					ODR.[emp_codigo] = EMP.[empr_codigo]
	INNER JOIN (SELECT *  
				FROM [TechCoreDB].[dbo].[GEN_SUCURSALES]
				) AS SUC ON
					ODR.[emp_codigo] = SUC.[emp_codigo]
						AND
					ODR.[suc_codigo] = SUC.[suc_codigo]
	LEFT OUTER JOIN (SELECT EMP.[empr_nombre]
				,VEH.[emp_codigo]
				,VEH.[mar_codigo]
				,VEH.[veh_codigo]
				,MARC.[mar_nombre]
				,VEH.[mod_codigo]
				,MOD.[mod_nombre]
				,VEH.[smo_codigo]
				,SMOD.[smo_nombre]
				,EQUI.[tal_modelo]
				,EQUI.[TAL_MOD_NOMBRE]
				,EQUI.[tipo_motor_codigo]
				,EQUI.[TAL_MOT_DESC]
				,VEH.[veh_dominio]
				,VEH.[veh_nro_vin]
				,VEH.[veh_serie]
			--	,VEH.[veh_nro_motor]
			--	,VEH.[veh_chasis]
			--	,VEH.[veh_marcachasis]
			--	,VEH.[veh_marcamotor]
			--	,VEH.[col_codigo]
			--	,VEH.[veh_concesionaria]
				,VEH.[veh_a�o_fab]
			--	,VEH.[veh_kilometraje]
			--	,VEH.[ubi_codigo]
			--	,VEH.[veh_placa_oval]
				,VEH.[veh_sucursal]
				,SUC.[suc_nombre]
			--	,VEH.[veh_certificado]
			--	,VEH.[veh_fecha_certificado]
				,VEH.[veh_tipo_motor]
				,VEH.[veh_usado_nuevo]
				,VEH.[veh_nacional_importado]
				,VEH.[veh_observaciones]
			--	,VEH.[tip_codigo]
			--	,VEH.[veh_esbiendeuso]
			--	,VEH.[veh_estaenventa]
			--	,VEH.[veh_precio_venta]
			--	,VEH.[veh_fecha_def_precio]
			--	,VEH.[veh_estado]
			--	,VEH.[ef_codigo]
			--	,VEH.[veh_descripcion_fiscal]
			--	,VEH.[veh_fecha_compra]
				,VEH.[veh_fecha_fin_garantia]
				,VEH.[veh_fecha_ini_garantia]
				,VEH.[veh_fecha_venta]
			FROM [TechCoreDB].[dbo].[GEN_VEHICULOS] AS VEH
				INNER JOIN (SELECT * 
							FROM [TechCoreDB].[dbo].[GEN_EMPRESAS]
							) AS EMP ON
								VEH.[emp_codigo] = EMP.[empr_codigo]
				INNER JOIN (SELECT *  
							FROM [TechCoreDB].[dbo].[GEN_SUCURSALES]
							) AS SUC ON
								VEH.[emp_codigo] = SUC.[emp_codigo]
									AND
								VEH.[veh_sucursal] = SUC.[suc_codigo]
				INNER JOIN (SELECT * 
							FROM [TechCoreDB].[dbo].[GEN_MARCAS]
							) AS MARC ON
								VEH.[emp_codigo] = MARC.[emp_codigo]
									AND
								VEH.[mar_codigo] = MARC.[mar_codigo]
				INNER JOIN (SELECT * 
							FROM [TechCoreDB].[dbo].[GEN_MODELOS]
							) AS MOD ON
								VEH.[emp_codigo] = MOD.[emp_codigo]
									AND
								VEH.[mar_codigo] = MOD.[mar_codigo]
									AND
								VEH.[mod_codigo] = MOD.[mod_codigo]
				INNER JOIN (SELECT * 
							FROM [TechCoreDB].[dbo].[GEN_SUBMODELOS]
							) AS SMOD ON
								VEH.[emp_codigo] = SMOD.[emp_codigo]
									AND
								VEH.[mod_codigo] = SMOD.[mod_codigo]
									AND
								VEH.[smo_codigo] = SMOD.[smo_codigo]
				INNER JOIN (SELECT EQI.*, TMOD.[talmod_nombre] AS TAL_MOD_NOMBRE, TTMOT.[descripcion] AS TAL_MOT_DESC
							FROM [TechCoreDB].[dbo].[TAL_EQUIVALENCIAS] AS EQI
								INNER JOIN (SELECT *
											FROM [TechCoreDB].[dbo].[TAL_TIPO_MOTOR]
											)  AS TTMOT ON
											EQI.[emp_codigo] = TTMOT.[emp_codigo]
												AND
											EQI.[mar_codigo] = TTMOT.[mar_codigo]
												AND
											EQI.[tipo_motor_codigo] = TTMOT.[tipo_motor_codigo]
								INNER JOIN (SELECT * 
											FROM [TechCoreDB].[dbo].[TAL_MODELOS]
											)  AS TMOD ON
											EQI.[emp_codigo] = TMOD.[emp_codigo]
												AND
											EQI.[mar_codigo] = TMOD.[mar_codigo]
												AND
											EQI.[tal_modelo] = TMOD.[talmod_codigo]
							) AS EQUI ON
								VEH.[emp_codigo] = EQUI.[emp_codigo]
									AND
								VEH.[mar_codigo] = EQUI.[mar_codigo]
									AND
								VEH.[mod_codigo] = EQUI.[mod_codigo]
									AND
								VEH.[smo_codigo] = EQUI.[smo_codigo]
				) AS MMM ON
					ODR.[veh_codigo] = MMM.[veh_codigo]
	LEFT OUTER JOIN (SELECT CalipsoProduccion.dbo.CLIENTE.CODIGO AS [N� cliente]
					,CASE WHEN CalipsoProduccion.dbo.Vc_PERSONA_Consulta.TIPOPERSONA = 'J' THEN CalipsoProduccion.dbo.CLIENTE.DENOMINACION
						  ELSE CalipsoProduccion.dbo.Vc_PERSONA_Consulta.NOMBRE END AS [Razon Social]
					,CalipsoProduccion.dbo.V_DOMICILIO_Consulta.CALLE
					,CalipsoProduccion.dbo.V_DOMICILIO_Consulta.BARRIO
					,CalipsoProduccion.dbo.V_DOMICILIO_Consulta.CODPOS AS CP
					,CalipsoProduccion.dbo.CIUDAD.NOMBRE AS Ciudad
					,CalipsoProduccion.dbo.PROVINCIA.NOMBRE AS Provincia
					,CalipsoProduccion.dbo.V_UD_CLIENTE.TeParticular AS Tel�fono
					,CalipsoProduccion.dbo.V_UD_CLIENTE.TeLaboral AS [Tel. laboral]
					,CalipsoProduccion.dbo.V_UD_CLIENTE.Celular
					,CalipsoProduccion.dbo.DIRECCIONELECTRONICA.DIRECCIONELECTRONICA AS Mail
					,CalipsoProduccion.dbo.TIPODOCUMENTO.TIPODOCUMENTO AS [Tipo documento]
					,CalipsoProduccion.dbo.Vc_PERSONA_Consulta.NUMERODOCUMETO AS [N� documento]
					,CalipsoProduccion.dbo.Vc_PERSONA_Consulta.CUIT
					,SUBSTRING(CalipsoProduccion.dbo.Vc_PERSONA_Consulta.FECHANACIMIENTO, 7, 2) + '/' + SUBSTRING(CalipsoProduccion.dbo.Vc_PERSONA_Consulta.FECHANACIMIENTO, 5, 2) + '/' + SUBSTRING(CalipsoProduccion.dbo.Vc_PERSONA_Consulta.FECHANACIMIENTO, 1, 4) AS [Fecha nacimiento]
					,CASE WHEN CAST(SUBSTRING(CalipsoProduccion.dbo.Vc_PERSONA_Consulta.FECHANACIMIENTO, 1, 4) AS INT) < 1900 THEN '' 
						  ELSE DATEDIFF(YEAR, CONVERT(DATETIME, SUBSTRING(CalipsoProduccion.dbo.Vc_PERSONA_Consulta.FECHANACIMIENTO, 7, 2) + '/' + SUBSTRING(CalipsoProduccion.dbo.Vc_PERSONA_Consulta.FECHANACIMIENTO, 5, 2) + '/' + SUBSTRING(CalipsoProduccion.dbo.Vc_PERSONA_Consulta.FECHANACIMIENTO, 1, 4)), GETDATE()) END AS Edad
					,CalipsoProduccion.dbo.ITEMTIPOCLASIFICADOR.NOMBRE AS [Tipo cliente]
				FROM CalipsoProduccion.dbo.CLIENTE WITH (nolock)  
						LEFT OUTER JOIN CalipsoProduccion.dbo.Vc_PERSONA_Consulta ON
							CalipsoProduccion.dbo.CLIENTE.ENTEASOCIADO_ID = CalipsoProduccion.dbo.Vc_PERSONA_Consulta.ID
						LEFT OUTER JOIN CalipsoProduccion.dbo.V_DOMICILIO_Consulta ON
							CalipsoProduccion.dbo.CLIENTE.DOMICILIOENTREGA_ID = CalipsoProduccion.dbo.V_DOMICILIO_Consulta.ID
						LEFT OUTER JOIN CalipsoProduccion.dbo.V_UD_CLIENTE WITH (nolock) ON 
							CalipsoProduccion.dbo.CLIENTE.BOEXTENSION_ID = CalipsoProduccion.dbo.V_UD_CLIENTE.ID
						LEFT OUTER JOIN CalipsoProduccion.dbo.DIRECCIONELECTRONICA WITH (nolock) ON
							CalipsoProduccion.dbo.Vc_PERSONA_Consulta.DIRECELECTRONICAPRINCIPAL_ID = CalipsoProduccion.dbo.DIRECCIONELECTRONICA.ID 
						LEFT OUTER JOIN CalipsoProduccion.dbo.TIPODOCUMENTO WITH (nolock) ON
							CalipsoProduccion.dbo.Vc_PERSONA_Consulta.TIPODOCUMENTO_ID = CalipsoProduccion.dbo.TIPODOCUMENTO.ID 
						LEFT OUTER JOIN CalipsoProduccion.dbo.PROVINCIA WITH (nolock) ON
							CalipsoProduccion.dbo.V_DOMICILIO_Consulta.PROVINCIA_ID = CalipsoProduccion.dbo.PROVINCIA.ID
						LEFT OUTER JOIN CalipsoProduccion.dbo.CIUDAD WITH (nolock) ON
							CalipsoProduccion.dbo.V_DOMICILIO_Consulta.CIUDAD_ID = CalipsoProduccion.dbo.CIUDAD.ID 
						LEFT OUTER JOIN CalipsoProduccion.dbo.ITEMTIPOCLASIFICADOR WITH (nolock) ON 
							CalipsoProduccion.dbo.V_UD_CLIENTE.TipoCliente_ID = CalipsoProduccion.dbo.ITEMTIPOCLASIFICADOR.ID 
						INNER JOIN CalipsoProduccion.dbo.POSICIONADORIMPUESTOS AS pos WITH (nolock) ON 
							pos.ID = CalipsoProduccion.dbo.CLIENTE.POSICIONADORIMPUESTOS_ID
						INNER JOIN CalipsoProduccion.dbo.ITEMPOSICIONADORIMPUESTOS AS item WITH (nolock) ON 
							item.BO_PLACE_ID = pos.ITEMSPOSICIONADORIMPUESTOS_ID 
						INNER JOIN CalipsoProduccion.dbo.DEFINICIONIMPUESTO AS def WITH (nolock) ON 
							def.ID = item.DEFINICIONIMPUESTO_ID 
						INNER JOIN CalipsoProduccion.dbo.IMPUESTO AS im WITH (nolock) ON 
							def.IMPUESTO_ID = im.ID 
								AND 
							im.ID = '728878A8-A2F7-4C45-9E88-94844529503A' 
						INNER JOIN CalipsoProduccion.dbo.POSICIONIMPUESTO AS posimp WITH (nolock) ON 
							posimp.ID = item.POSICIONIMPUESTO_ID 
						) AS CLI ON
		ODR.[cli_codigo] = CLI.[N� cliente]
	LEFT OUTER JOIN (SELECT CODIGO, MIN(NOMBRE) AS NOMBRE
						FROM CalipsoProduccion.dbo.EMPLEADO AS EMP WITH (nolock)
								INNER JOIN CalipsoProduccion.dbo.Vc_PERSONA_Consulta AS PER ON 
									EMP.ENTEASOCIADO_ID = PER.ID
--						WHERE CODIGO = 32739315
						GROUP BY CODIGO
					) AS EPL ON
						ODR.[empl_codigo] = EPL.[CODIGO]
WHERE SUC.[suc_codigo] = 21 
	AND ODR.[odr_fecha_aper] >= CONVERT(DATETIME, '06/08/2012')


-- AND ODR.[veh_codigo] = 113107
--ODR.[odr_codigo] = 1105227
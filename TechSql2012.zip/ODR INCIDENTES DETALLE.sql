
-- LLEVA 1:44 SEGU
-- DETALLE DE LOS INCIDENTES DE CADA VEH�CULO
SELECT INC.[emp_codigo]
--	  ,char(9) AS '|'
      ,INC.[suc_codigo]
--	  ,char(9) AS '|'
      ,INC.[Inc_codigo]
--	  ,char(9) AS '|'
      ,INC.[Inc_numero]
--	  ,char(9) AS '|'
      ,INC.[doc_codigo]
--	  ,char(9) AS '|'
      ,INC.[doc_tipo]
--	  ,char(9) AS '|'
      ,INC.[tmo_codigo]
--	  ,char(9) AS '|'
      ,INC.[Inc_descripcion]
--	  ,char(9) AS '|'
      ,INC.[car_codigo]
--	  ,char(9) AS '|'
	  ,CAR.[car_nombre]
--	  ,char(9) AS '|'
      ,INC.[empl_codigo]
--	  ,char(9) AS '|'
      ,INC.[Inc_Tiempo_Est]
--	  ,char(9) AS '|'
      ,INC.[Inc_hs_ini]
--	  ,char(9) AS '|'
      ,INC.[Inc_hs_fin]
--	  ,char(9) AS '|'
      ,INC.[Inc_estado]
--	  ,char(9) AS '|'
      ,INC.[pre_confirmar]
--	  ,char(9) AS '|'
      ,INC.[mar_codigo]
--	  ,char(9) AS '|'
      ,INC.[mod_codigo]
--	  ,char(9) AS '|'
      ,INC.[tipo_motor_codigo]
--	  ,char(9) AS '|'
      ,INC.[precio_estimado] 
FROM [TechCoreDB].[dbo].[TAL_INCIDENTES] AS INC 
	INNER JOIN (SELECT [emp_codigo]
					  ,[car_codigo]
					  ,[car_nombre]
					  ,[car_descripcion]
					  ,[car_estado]
				  FROM [TechCoreDB].[dbo].[GEN_CARGO]) AS CAR ON
		INC.[emp_codigo] = CAR.[emp_codigo]
			AND
		INC.[car_codigo] = CAR.[car_codigo]





DECLARE @chr_BCP_ARCHIVO VARCHAR(5000)
SET @chr_BCP_ARCHIVO='bcp TechCoreDB.dbo.TAL_INCIDENTES out "C:\bcp\TalIncidentes.dat" -T -c'
EXEC master..xp_cmdshell @chr_BCP_ARCHIVO

WHERE INC.[doc_codigo] = 2209	--1105227



-- AGRUPACI�N DE LOS INCIDENTES POR CADA ODR
SELECT TOP 100 INC.[emp_codigo]
      ,INC.[doc_codigo]
	  ,MIN(CASE WHEN INC.[Inc_numero] = 1 THEN CAST(INC.[Inc_numero] AS NVARCHAR(15)) + '.-' + INC.[Inc_descripcion] + '| Cargo:' + CAST(INC.[car_codigo] AS NVARCHAR(3)) + '-' +  CAR.[car_nombre] + '| Est:' + INC.[Inc_estado] ELSE NULL END) AS INC_01
	  ,MIN(CASE WHEN INC.[Inc_numero] = 2 THEN CAST(INC.[Inc_numero] AS NVARCHAR(15)) + '.-' + INC.[Inc_descripcion] + '| Cargo:' + CAST(INC.[car_codigo] AS NVARCHAR(3)) + '-' +  CAR.[car_nombre] + '| Est:' + INC.[Inc_estado] ELSE NULL END) AS INC_02
	  ,MIN(CASE WHEN INC.[Inc_numero] = 3 THEN CAST(INC.[Inc_numero] AS NVARCHAR(15)) + '.-' + INC.[Inc_descripcion] + '| Cargo:' + CAST(INC.[car_codigo] AS NVARCHAR(3)) + '-' +  CAR.[car_nombre] + '| Est:' + INC.[Inc_estado] ELSE NULL END) AS INC_03
	  ,MIN(CASE WHEN INC.[Inc_numero] = 4 THEN CAST(INC.[Inc_numero] AS NVARCHAR(15)) + '.-' + INC.[Inc_descripcion] + '| Cargo:' + CAST(INC.[car_codigo] AS NVARCHAR(3)) + '-' +  CAR.[car_nombre] + '| Est:' + INC.[Inc_estado] ELSE NULL END) AS INC_04
	  ,MIN(CASE WHEN INC.[Inc_numero] = 5 THEN CAST(INC.[Inc_numero] AS NVARCHAR(15)) + '.-' + INC.[Inc_descripcion] + '| Cargo:' + CAST(INC.[car_codigo] AS NVARCHAR(3)) + '-' +  CAR.[car_nombre] + '| Est:' + INC.[Inc_estado] ELSE NULL END) AS INC_05	
	  ,SUM(CASE WHEN INC.[Inc_numero] = 1 OR INC.[Inc_numero] = 2 OR INC.[Inc_numero] = 3 OR INC.[Inc_numero] = 4 OR INC.[Inc_numero] = 5 THEN INC.[precio_estimado] ELSE NULL END) AS PrEst
	  ,MIN(CASE WHEN INC.[car_codigo] = 1 THEN CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre] 
				WHEN INC.[car_codigo] = 2 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre] 
				WHEN INC.[car_codigo] = 3 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				WHEN INC.[car_codigo] = 4 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				WHEN INC.[car_codigo] = 5 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				WHEN INC.[car_codigo] = 6 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				WHEN INC.[car_codigo] = 7 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				WHEN INC.[car_codigo] = 8 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				WHEN INC.[car_codigo] = 9 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				WHEN INC.[car_codigo] = 10 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				WHEN INC.[car_codigo] = 11 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				WHEN INC.[car_codigo] = 12 THEN + '|' + CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + [car_nombre]
				ELSE NULL END) AS CARGO
FROM [TechCoreDB].[dbo].[TAL_INCIDENTES] AS INC 
	INNER JOIN (SELECT [emp_codigo]
					  ,[car_codigo]
					  ,[car_nombre]
					  ,[car_descripcion]
					  ,[car_estado]
				  FROM [TechCoreDB].[dbo].[GEN_CARGO]) AS CAR ON
		INC.[emp_codigo] = CAR.[emp_codigo]
			AND
		INC.[car_codigo] = CAR.[car_codigo]
WHERE INC.[doc_codigo] = 1105275		--1105227
GROUP BY INC.[emp_codigo]
		,INC.[doc_codigo]



-- RESUMEN DE LOS CARGOS
SELECT CASE WHEN ICC.[CARGO_INC01] IS NOT NULL THEN ICC.[CARGO_INC01] ELSE '' END 
		+ CASE WHEN ICC.[CARGO_INC02] IS NOT NULL THEN + '|' + ICC.[CARGO_INC02] ELSE '' END
		+ CASE WHEN ICC.[CARGO_INC03] IS NOT NULL THEN + '|' + ICC.[CARGO_INC03] ELSE '' END
		+ CASE WHEN ICC.[CARGO_INC04] IS NOT NULL THEN + '|' + ICC.[CARGO_INC04] ELSE '' END 
		+ CASE WHEN ICC.[CARGO_INC05] IS NOT NULL THEN + '|' + ICC.[CARGO_INC05] ELSE '' END  AS CARGOS
FROM(
SELECT TOP 100 CRS.[emp_codigo]
	  ,CRS.[suc_codigo]
	  ,CRS.[doc_codigo]
	  ,MIN(CASE WHEN CRS.[INCID] = 1 THEN CRS.[CARGO] ELSE NULL END) AS CARGO_INC01
	  ,MIN(CASE WHEN CRS.[INCID] = 2 THEN CRS.[CARGO] ELSE NULL END) AS CARGO_INC02
	  ,MIN(CASE WHEN CRS.[INCID] = 3 THEN CRS.[CARGO] ELSE NULL END) AS CARGO_INC03
	  ,MIN(CASE WHEN CRS.[INCID] = 4 THEN CRS.[CARGO] ELSE NULL END) AS CARGO_INC04
	  ,MIN(CASE WHEN CRS.[INCID] = 5 THEN CRS.[CARGO] ELSE NULL END) AS CARGO_INC05
FROM (SELECT INC.[emp_codigo]
			  ,INC.[suc_codigo]
			  ,INC.[doc_codigo]
			  ,MIN(INC.[Inc_numero]) AS INCID
			  ,MIN(INC.[car_codigo]) AS CARG
			  ,CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + CAR.[car_nombre] AS CARGO
			  ,COUNT(*) AS TOTAL
		FROM [TechCoreDB].[dbo].[TAL_INCIDENTES] AS INC 
			INNER JOIN (SELECT [emp_codigo]
							  ,[car_codigo]
							  ,[car_nombre]
							  ,[car_descripcion]
							  ,[car_estado]
						  FROM [TechCoreDB].[dbo].[GEN_CARGO]
							WHERE [emp_codigo] = 2) AS CAR ON
				INC.[emp_codigo] = CAR.[emp_codigo]
					AND
				INC.[car_codigo] = CAR.[car_codigo]
		WHERE INC.[emp_codigo] = 2 
			AND INC.[suc_codigo] = 21 
--			AND INC.[doc_codigo] = 1028847
		GROUP BY INC.[emp_codigo]
			  ,INC.[suc_codigo]
			  ,INC.[doc_codigo]
			  ,CAST(INC.[car_codigo] AS NVARCHAR(5)) + '.-' + CAR.[car_nombre]
		) AS CRS
GROUP BY CRS.[emp_codigo]
	  ,CRS.[suc_codigo]
	  ,CRS.[doc_codigo]
) AS ICC

-- Pareto de los Incidentes
SELECT TOP 100 [Inc_numero], COUNT([Inc_numero]) AS TOTAL, SUM(TotalInc)
	FROM [TechCoreDB].[dbo].[TAL_INCIDENTES] AS INC
		INNER JOIN (SELECT COUNT([Inc_numero]) AS TotalInc FROM [TechCoreDB].[dbo].[TAL_INCIDENTES]) AS TOTINC
	GROUP BY [Inc_numero]) AS INC


		ORDER BY COUNT([Inc_numero]) DESC



-- Pareto de los cargos
SELECT TOP 100 INC.[emp_codigo]
      ,INC.[car_codigo]
	  ,COUNT(*) AS TOTAL	 
FROM [TechCoreDB].[dbo].[TAL_INCIDENTES] AS INC 
	INNER JOIN (SELECT [emp_codigo]
					  ,[car_codigo]
					  ,[car_nombre]
					  ,[car_descripcion]
					  ,[car_estado]
				  FROM [TechCoreDB].[dbo].[GEN_CARGO]
					WHERE [emp_codigo] = 2) AS CAR ON
		INC.[emp_codigo] = CAR.[emp_codigo]
			AND
		INC.[car_codigo] = CAR.[car_codigo]
WHERE INC.[emp_codigo] = 2 --INC.[doc_codigo] = 1099518		--1105227
GROUP BY INC.[emp_codigo]
		,INC.[car_codigo]
ORDER BY COUNT(*) DESC
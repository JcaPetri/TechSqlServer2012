use TechCoreDB
go
create view JCP_IncidentesDetalle
as 
	SELECT TOP 100 INC.[emp_codigo]
		  ,INC.[suc_codigo]
		  ,INC.[Inc_codigo]
		  ,INC.[Inc_numero]
		  ,INC.[doc_codigo]
		  ,INC.[doc_tipo]
		  ,INC.[tmo_codigo]
		  ,INC.[Inc_descripcion]
		  ,INC.[car_codigo]
		  ,CAR.[car_nombre]
		  ,INC.[empl_codigo]
		  ,INC.[Inc_Tiempo_Est]
		  ,INC.[Inc_hs_ini]
		  ,INC.[Inc_hs_fin]
		  ,INC.[Inc_estado]
		  ,INC.[pre_confirmar]
		  ,INC.[mar_codigo]
		  ,INC.[mod_codigo]
		  ,INC.[tipo_motor_codigo]
		  ,INC.[precio_estimado] 
	FROM [TechCoreDB].[dbo].[TAL_INCIDENTES] AS INC 
		INNER JOIN (SELECT [emp_codigo]
						  ,[car_codigo]
						  ,[car_nombre]
						  ,[car_descripcion]
						  ,[car_estado]
					  FROM [TechCoreDB].[dbo].[GEN_CARGO]) AS CAR ON
			INC.[emp_codigo] = CAR.[emp_codigo]
				AND
			INC.[car_codigo] = CAR.[car_codigo]
go
declare @sql varchar(8000)
select @sql = 'bcp TechCoreDB..JCP_IncidentesDetalle out c:\bcp\ODRIncidentes.txt -c -T' + erpserver
exec TechCoreDB..xp_cmdshell @sql



DECLARE @FileName VARCHAR(100)
DECLARE @BCPCommand VARCHAR(8000)

SET @FileName = 'c:\bcp\ODRIncidentes.txt'

SET @BCPCommand = 'bcp "SELECT TOP 10 * FROM [TechCoreDB].[dbo].[TAL_INCIDENTES]" queryout "'
SET @BCPCommand = @BCPCommand + @FileName + '" -c - T'

EXEC TechCoreDB..xp_cmdshell @BCPCommand



BCP "SELECT TOP 100 * FROM [TechCoreDB].[dbo].[TAL_INCIDENTES]" queryout C:\bcp\TalInc.dat -c -t, -r \r\n -S erpserver\TechCoreDB -T

